import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

// Tipografía Poppins — misma usada por Detallitos con Amor
const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

// Metadatos de la aplicación - Detallitos con Amor · Gifting Studio
export const metadata: Metadata = {
  title: "Detallitos con Amor · Gifting Studio — Gestión Documental",
  description:
    "Plataforma digital para la organización, almacenamiento y consulta de documentos de Detallitos con Amor · Gifting Studio. Cada detalle cuenta una historia de amor.",
  keywords: [
    "Detallitos con Amor",
    "Gifting Studio",
    "Gestión Documental",
    "Ramos Eternos",
    "Macetas Curadas",
    "Detalles Personalizados",
    "Colección Corporativa",
  ],
  authors: [{ name: "Detallitos con Amor · Gifting Studio" }],
  icons: {
    icon: "/logo-dca.jpeg",
  },
  openGraph: {
    title: "Detallitos con Amor · Gifting Studio",
    description: "Gestión Documental — Cada detalle cuenta una historia de amor",
    siteName: "Detallitos con Amor",
    locale: "es_CO",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${poppins.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
