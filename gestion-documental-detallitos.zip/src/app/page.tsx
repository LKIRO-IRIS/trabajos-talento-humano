"use client";

/**
 * Página principal del sistema de Gestión Documental de Talento Humano.
 *
 * Estructura general:
 * - Sidebar de navegación con los 7 procesos.
 * - Encabezado con el nombre de la empresa y buscador global.
 * - Vista principal (panel) o vista de carpeta individual.
 *
 * El estado se mantiene en este componente (código comentado):
 * - activeProcessId: proceso seleccionado (null = panel principal).
 * - documentsByProcess: documentos por carpeta (cache en memoria).
 * - globalSearch: consulta del buscador general del panel.
 * - folderSearch: consulta del buscador dentro de una carpeta.
 *
 * Los documentos se persisten en IndexedDB (almacenamiento persistente).
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { Sidebar } from "@/components/file-manager/sidebar";
import { Header } from "@/components/file-manager/header";
import { Dashboard } from "@/components/file-manager/dashboard";
import { FolderView } from "@/components/file-manager/folder-view";
import { useToast } from "@/hooks/use-toast";
import {
  PROCESSES,
  isFileAllowed,
  getCategoryInfo,
} from "@/lib/processes";
import {
  saveDocument,
  deleteDocument,
  getDocumentsByProcess,
  getAllDocuments,
  searchDocuments,
  downloadDocument,
  getDocumentSheet,
  updateDocumentSheet,
  type DocumentMetadata,
} from "@/lib/document-store";
import {
  createNewFormat,
  getFormat,
  getFormatsByProcess,
  saveFormat,
  deleteFormat,
  formatToMetadata,
  type EditableFormat,
} from "@/lib/format-store";

export default function HomePage() {
  // Proceso actualmente seleccionado (null = panel principal)
  const [activeProcessId, setActiveProcessId] = useState<string | null>(null);
  // Documentos por proceso (cache en memoria, persistidos en IndexedDB)
  const [documentsByProcess, setDocumentsByProcess] = useState<
    Record<string, DocumentMetadata[]>
  >({});
  // Formatos editables por proceso (cache en memoria)
  const [formatsByProcess, setFormatsByProcess] = useState<
    Record<string, EditableFormat[]>
  >({});
  // Consulta del buscador general del panel
  const [globalSearch, setGlobalSearch] = useState("");
  // Consulta del buscador dentro de la carpeta actual
  const [folderSearch, setFolderSearch] = useState("");
  // Estado de carga inicial
  const [loading, setLoading] = useState(true);
  // Estado de subida de archivos
  const [uploading, setUploading] = useState(false);
  // Resultados de búsqueda global
  const [globalResults, setGlobalResults] = useState<DocumentMetadata[]>([]);
  // Sidebar abierto en móvil
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const { toast } = useToast();

  /**
   * Carga inicial de documentos y formatos editables desde IndexedDB.
   * Se ejecuta una sola vez al montar la página.
   */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const all = await getAllDocuments();
        if (cancelled) return;
        const grouped: Record<string, DocumentMetadata[]> = {};
        for (const doc of all) {
          if (!grouped[doc.processId]) grouped[doc.processId] = [];
          grouped[doc.processId].push(doc);
        }
        // Cargar también los formatos editables y agregarlos a la lista
        const fmtsByProc: Record<string, EditableFormat[]> = {};
        for (const p of PROCESSES) {
          const fmts = await getFormatsByProcess(p.id);
          if (fmts.length > 0) {
            fmtsByProc[p.id] = fmts;
            if (!grouped[p.id]) grouped[p.id] = [];
            for (const f of fmts) {
              grouped[p.id].push(formatToMetadata(f));
            }
          }
        }
        if (cancelled) return;
        setDocumentsByProcess(grouped);
        setFormatsByProcess(fmtsByProc);
      } catch (err) {
        console.error("Error al cargar documentos:", err);
        toast({
          title: "Error",
          description: "No se pudieron cargar los documentos almacenados.",
          variant: "destructive",
        });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [toast]);

  /**
   * Conteos por carpeta y total general.
   */
  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const p of PROCESSES) {
      c[p.id] = documentsByProcess[p.id]?.length ?? 0;
    }
    return c;
  }, [documentsByProcess]);

  const total = useMemo(
    () => Object.values(counts).reduce((a, b) => a + b, 0),
    [counts]
  );

  /**
   * Ejecuta la búsqueda global cuando cambia la consulta.
   */
  useEffect(() => {
    if (!globalSearch.trim()) {
      setGlobalResults([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const results = await searchDocuments(globalSearch);
        if (!cancelled) setGlobalResults(results);
      } catch (err) {
        console.error("Error en la búsqueda global:", err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [globalSearch]);

  /**
   * Refresca los documentos de un proceso desde IndexedDB,
   * incluyendo los formatos editables.
   */
  const refreshProcess = useCallback(async (processId: string) => {
    try {
      const docs = await getDocumentsByProcess(processId);
      const fmts = await getFormatsByProcess(processId);
      setFormatsByProcess((prev) => ({ ...prev, [processId]: fmts }));
      // Combinar documentos binarios y formatos editables en una sola lista
      const combined = [...docs];
      for (const f of fmts) {
        combined.push(formatToMetadata(f));
      }
      // Ordenar por fecha descendente
      combined.sort(
        (a, b) =>
          new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
      );
      setDocumentsByProcess((prev) => ({ ...prev, [processId]: combined }));
    } catch (err) {
      console.error("Error al refrescar documentos:", err);
    }
  }, []);

  /**
   * Selecciona un proceso (o vuelve al panel principal).
   * Limpia el buscador interno al cambiar de carpeta.
   */
  const handleSelectProcess = useCallback((processId: string | null) => {
    setActiveProcessId(processId);
    setFolderSearch("");
    setMobileSidebarOpen(false);
    // Si se selecciona un proceso, limpiar la búsqueda global
    if (processId) setGlobalSearch("");
  }, []);

  /**
   * Sube uno o varios archivos a la carpeta activa, clasificándolos en una categoría.
   * Muestra mensajes de confirmación y error según corresponda.
   */
  const handleUpload = useCallback(
    async (files: File[], category: string) => {
      if (!activeProcessId) return;
      setUploading(true);
      let success = 0;
      let failed: string[] = [];
      const categoryName = getCategoryInfo(category).name;
      const processName =
        PROCESSES.find((p) => p.id === activeProcessId)?.name ?? "";
      try {
        for (const file of files) {
          if (!isFileAllowed(file.name)) {
            failed.push(file.name);
            continue;
          }
          try {
            await saveDocument(file, activeProcessId, category);
            success++;
          } catch (err) {
            console.error("Error al guardar documento:", err);
            failed.push(file.name);
          }
        }
        await refreshProcess(activeProcessId);
        if (success > 0) {
          toast({
            title: "Archivos subidos correctamente",
            description: `${success} archivo${
              success !== 1 ? "s" : ""
            } guardado${success !== 1 ? "s" : ""} en ${processName} · categoría "${categoryName}".`,
          });
        }
        if (failed.length > 0) {
          toast({
            title: "Algunos archivos no se pudieron subir",
            description: `No se permitieron: ${failed.join(
              ", "
            )}. Revise el formato (PDF, Word, Excel, PowerPoint o imagen).`,
            variant: "destructive",
          });
        }
        if (success === 0 && failed.length === 0) {
          toast({
            title: "No se subió ningún archivo",
            description: "Seleccione al menos un archivo para subir.",
          });
        }
      } finally {
        setUploading(false);
      }
    },
    [activeProcessId, refreshProcess, toast]
  );

  /**
   * Descarga un documento por su id.
   */
  const handleDownload = useCallback(
    async (id: string) => {
      try {
        await downloadDocument(id);
        toast({
          title: "Descarga iniciada",
          description: "El documento se está descargando en su navegador.",
        });
      } catch (err) {
        console.error("Error al descargar:", err);
        toast({
          title: "Error al descargar",
          description: "No se pudo descargar el documento.",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  /**
   * Elimina un documento o formato editable por su id y refresca la carpeta.
   */
  const handleDelete = useCallback(
    async (id: string) => {
      if (!activeProcessId) return;
      try {
        // Intentar eliminar como documento binario; si no existe,
        // intentar eliminar como formato editable.
        try {
          await deleteDocument(id);
        } catch {
          await deleteFormat(id);
        }
        await refreshProcess(activeProcessId);
        toast({
          title: "Documento eliminado",
          description: "El documento se eliminó correctamente.",
        });
      } catch (err) {
        console.error("Error al eliminar:", err);
        toast({
          title: "Error al eliminar",
          description: "No se pudo eliminar el documento.",
          variant: "destructive",
        });
      }
    },
    [activeProcessId, refreshProcess, toast]
  );

  /**
   * Crea un nuevo formato editable con código consecutivo.
   */
  const handleCreateFormat = useCallback(async (): Promise<EditableFormat | null> => {
    if (!activeProcessId) return null;
    try {
      const fmt = await createNewFormat(activeProcessId);
      // Guardar inmediatamente para que persista
      await saveFormat(fmt);
      await refreshProcess(activeProcessId);
      toast({
        title: "Formato creado",
        description: `Código asignado: ${fmt.code}. Ya puedes editarlo.`,
      });
      return fmt;
    } catch (err) {
      console.error("Error al crear formato:", err);
      toast({
        title: "Error al crear formato",
        description: "No se pudo crear el formato.",
        variant: "destructive",
      });
      return null;
    }
  }, [activeProcessId, refreshProcess, toast]);

  /**
   * Abre un formato editable existente.
   */
  const handleOpenFormat = useCallback(
    async (formatId: string): Promise<EditableFormat | null> => {
      try {
        const fmt = await getFormat(formatId);
        return fmt;
      } catch (err) {
        console.error("Error al abrir formato:", err);
        toast({
          title: "Error al abrir formato",
          description: "No se pudo cargar el formato.",
          variant: "destructive",
        });
        return null;
      }
    },
    [toast]
  );

  /**
   * Guarda un formato editable.
   */
  const handleSaveFormat = useCallback(
    async (format: EditableFormat) => {
      try {
        await saveFormat(format);
        if (activeProcessId) await refreshProcess(activeProcessId);
        toast({
          title: "Formato guardado",
          description: `"${format.title}" se guardó correctamente.`,
        });
      } catch (err) {
        console.error("Error al guardar formato:", err);
        toast({
          title: "Error al guardar",
          description: "No se pudo guardar el formato.",
          variant: "destructive",
        });
      }
    },
    [activeProcessId, refreshProcess, toast]
  );

  /**
   * Abre un documento Excel en el editor.
   */
  const handleOpenSheet = useCallback(
    async (docId: string): Promise<{ data: any[][]; name: string } | null> => {
      try {
        const result = await getDocumentSheet(docId);
        return result;
      } catch (err) {
        console.error("Error al abrir Excel:", err);
        toast({
          title: "Error al abrir Excel",
          description: "No se pudo cargar el archivo para editar.",
          variant: "destructive",
        });
        return null;
      }
    },
    [toast]
  );

  /**
   * Guarda los datos editados de un Excel.
   */
  const handleSaveSheet = useCallback(
    async (docId: string, data: any[][], name: string) => {
      try {
        await updateDocumentSheet(docId, data, name);
        if (activeProcessId) await refreshProcess(activeProcessId);
        toast({
          title: "Excel guardado",
          description: `"${name}" se guardó correctamente.`,
        });
      } catch (err) {
        console.error("Error al guardar Excel:", err);
        toast({
          title: "Error al guardar",
          description: "No se pudo guardar el Excel.",
          variant: "destructive",
        });
      }
    },
    [activeProcessId, refreshProcess, toast]
  );

  // Proceso activo (información completa)
  const activeProcess = activeProcessId
    ? PROCESSES.find((p) => p.id === activeProcessId) ?? null
    : null;

  // Documentos visibles en la carpeta activa (filtrados por la búsqueda interna)
  const activeDocuments = activeProcessId
    ? documentsByProcess[activeProcessId] ?? []
    : [];

  return (
    <div className="flex min-h-screen bg-[#FFFBF7]">
      {/* Barra lateral de navegación */}
      <Sidebar
        activeProcessId={activeProcessId}
        counts={counts}
        total={total}
        onSelect={handleSelectProcess}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Contenido principal */}
      <div className="flex min-w-0 flex-1 flex-col">
        <Header
          searchQuery={globalSearch}
          onSearchChange={setGlobalSearch}
          onOpenSidebar={() => setMobileSidebarOpen(true)}
          showGlobalSearch={!activeProcessId}
        />

        <main className="flex-1 px-4 py-6 lg:px-8 lg:py-8">
          {/* Skeleton de carga inicial */}
          {loading ? (
            <div className="space-y-4">
              <div className="h-32 animate-pulse rounded-xl bg-gray-200" />
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div
                    key={i}
                    className="h-44 animate-pulse rounded-xl bg-gray-200"
                  />
                ))}
              </div>
            </div>
          ) : activeProcess ? (
            <FolderView
              process={activeProcess}
              documents={activeDocuments}
              searchQuery={folderSearch}
              onSearchChange={setFolderSearch}
              onBack={() => handleSelectProcess(null)}
              onUpload={handleUpload}
              onDownload={handleDownload}
              onDelete={handleDelete}
              uploading={uploading}
              onCreateFormat={handleCreateFormat}
              onOpenFormat={handleOpenFormat}
              onSaveFormat={handleSaveFormat}
              onOpenSheet={handleOpenSheet}
              onSaveSheet={handleSaveSheet}
            />
          ) : (
            <Dashboard
              counts={counts}
              total={total}
              searchQuery={globalSearch}
              searchResults={globalResults}
              onOpenFolder={(pid) => handleSelectProcess(pid)}
            />
          )}
        </main>

        {/* Pie de página con la identidad de Detallitos con Amor */}
        <footer className="border-t border-[#F0E4D8] bg-[#2A1410] px-4 py-6 text-[#FFFBF7] lg:px-8">
          <div className="mx-auto flex max-w-5xl flex-col items-center gap-3 text-center">
            <p className="text-sm font-semibold">
              Detallitos con Amor · Gifting Studio
            </p>
            <p className="text-xs text-[#FFFBF7]/70">
              Diseño y elaboración de regalos personalizados artesanales. Cada
              detalle cuenta una historia de amor.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-[#FFD24B]">
              <a
                href="mailto:detallitosconamorth@gmail.com"
                className="hover:underline"
              >
                detallitosconamorth@gmail.com
              </a>
              <span className="text-[#FFFBF7]/30">·</span>
              <a
                href="tel:+573052554170"
                className="hover:underline"
              >
                +57 305 255 4170
              </a>
              <span className="text-[#FFFBF7]/30">·</span>
              <span>Lun a sáb, 8:00 a.m. – 6:00 p.m.</span>
              <span className="text-[#FFFBF7]/30">·</span>
              <span>Colombia</span>
            </div>
            <p className="mt-2 text-[11px] text-[#FFFBF7]/50">
              &copy; {new Date().getFullYear()} Detallitos con Amor · Gifting
              Studio · Hecho con dedicación en Colombia
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
