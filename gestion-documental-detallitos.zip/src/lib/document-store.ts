/**
 * Almacenamiento persistente y seguro de documentos usando IndexedDB.
 *
 * IndexedDB se elige sobre localStorage porque:
 * - Permite almacenar archivos binarios mucho más grandes (cientos de MB).
 * - Conserva los documentos después de cerrar y volver a abrir la página.
 * - Opera de forma asíncrona, sin bloquear la interfaz.
 *
 * Los metadatos de cada documento se guardan dentro del mismo registro
 * para mantener una estructura simple y portátil.
 */

import { isFileAllowed, DEFAULT_CATEGORY_ID } from "./processes";

export interface StoredDocument {
  /** Identificador único del documento */
  id: string;
  /** ID del proceso (carpeta) al que pertenece */
  processId: string;
  /**
   * Categoría de clasificación dentro del proceso:
   * "modelos" | "registros" | "formatos" | "documentos".
   * Los documentos antiguos sin categoría se interpretan como "documentos".
   */
  category?: string;
  /** Nombre original del archivo */
  name: string;
  /** Tamaño en bytes */
  size: number;
  /** Tipo MIME del archivo */
  mimeType: string;
  /** Fecha de carga ISO */
  uploadedAt: string;
  /** Contenido binario del archivo (Blob) */
  blob: Blob;
  /**
   * Para archivos Excel editables: datos de la hoja en formato JSON
   * (matriz de celdas) para permitir re-edición.
   */
  sheetData?: any[][];
}

export interface DocumentMetadata {
  id: string;
  processId: string;
  /** Categoría del documento (siempre definida en los metadatos) */
  category: string;
  name: string;
  size: number;
  mimeType: string;
  uploadedAt: string;
  /** Indica si el archivo es un Excel con datos editables (sheetData) */
  isEditableSheet?: boolean;
}

const DB_NAME = "human-talent-documents";
// Versión 2: incluye los stores de formatos editables y contadores.
const DB_VERSION = 2;
const STORE_NAME = "documents";
const FORMAT_STORE = "editable-formats";
const COUNTER_STORE = "format-counters";

/**
 * Abre (o crea) la base de datos IndexedDB.
 * Crea todos los stores necesarios en onupgradeneeded.
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      reject(new Error("IndexedDB no está disponible en este entorno."));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      // Store de documentos binarios
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("processId", "processId", { unique: false });
        store.createIndex("name", "name", { unique: false });
      }
      // Store de formatos editables (JSON)
      if (!db.objectStoreNames.contains(FORMAT_STORE)) {
        const store = db.createObjectStore(FORMAT_STORE, { keyPath: "id" });
        store.createIndex("processId", "processId", { unique: false });
      }
      // Store de contadores de numeración consecutiva
      if (!db.objectStoreNames.contains(COUNTER_STORE)) {
        db.createObjectStore(COUNTER_STORE, { keyPath: "processId" });
      }
    };
  });
}

/**
 * Genera un identificador único para cada documento.
 */
function generateId(): string {
  return `doc_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * Guarda un documento en la base de datos, asociado a un proceso y categoría.
 * Valida la extensión antes de almacenar.
 *
 * @param file Archivo a guardar.
 * @param processId ID del proceso (carpeta) al que pertenece.
 * @param category Categoría de clasificación dentro del proceso.
 * @returns Los metadatos del documento guardado.
 * @throws Error si el archivo tiene una extensión no permitida o falla la escritura.
 */
export async function saveDocument(
  file: File,
  processId: string,
  category: string = DEFAULT_CATEGORY_ID
): Promise<DocumentMetadata> {
  if (!isFileAllowed(file.name)) {
    throw new Error(
      `El archivo "${file.name}" tiene una extensión no permitida.`
    );
  }

  const db = await openDB();
  const doc: StoredDocument = {
    id: generateId(),
    processId,
    category,
    name: file.name,
    size: file.size,
    mimeType: file.type || "application/octet-stream",
    uploadedAt: new Date().toISOString(),
    blob: file,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.add(doc);
    request.onerror = () => reject(request.error);
    request.onsuccess = () =>
      resolve(toMetadata(doc));
    db.close();
  });
}

/**
 * Elimina un documento por su identificador.
 */
export async function deleteDocument(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
    db.close();
  });
}

/**
 * Obtiene los metadatos de todos los documentos de un proceso (carpeta).
 */
export async function getDocumentsByProcess(
  processId: string
): Promise<DocumentMetadata[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const index = store.index("processId");
    const request = index.getAll(processId);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const docs = (request.result as StoredDocument[]) || [];
      // Ordenar por fecha de carga descendente (más recientes primero)
      docs.sort(
        (a, b) =>
          new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
      );
      resolve(docs.map(toMetadata));
    };
    db.close();
  });
}

/**
 * Obtiene los metadatos de todos los documentos almacenados.
 */
export async function getAllDocuments(): Promise<DocumentMetadata[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const docs = (request.result as StoredDocument[]) || [];
      docs.sort(
        (a, b) =>
          new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
      );
      resolve(docs.map(toMetadata));
    };
    db.close();
  });
}

/**
 * Busca documentos por nombre (coincidencia parcial, insensible a mayúsculas).
 * Si se indica processId, limita la búsqueda a esa carpeta.
 */
export async function searchDocuments(
  query: string,
  processId?: string
): Promise<DocumentMetadata[]> {
  const all = processId
    ? await getDocumentsByProcess(processId)
    : await getAllDocuments();
  if (!query.trim()) return all;
  const q = query.trim().toLowerCase();
  return all.filter((d) => d.name.toLowerCase().includes(q));
}

/**
 * Recupera el Blob de un documento y dispara su descarga en el navegador.
 */
export async function downloadDocument(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = async () => {
      const doc = request.result as StoredDocument | undefined;
      if (!doc) {
        reject(new Error("El documento no existe."));
        db.close();
        return;
      }
      // Crear URL temporal y disparar la descarga
      const url = URL.createObjectURL(doc.blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      // Liberar la URL tras un breve retardo para asegurar la descarga
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      resolve();
    };
    db.close();
  });
}

/**
 * Actualiza los datos editables de un documento Excel.
 * Regenera el Blob con el nuevo contenido y actualiza metadatos.
 */
export async function updateDocumentSheet(
  id: string,
  sheetData: any[][],
  newName?: string
): Promise<void> {
  // Importar xlsx dinámicamente para no cargarlo en el bundle principal
  const XLSX = await import("xlsx");
  const ws = XLSX.utils.aoa_to_sheet(sheetData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Hoja 1");
  const arrayBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([arrayBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);
    getReq.onerror = () => reject(getReq.error);
    getReq.onsuccess = () => {
      const doc = getReq.result as StoredDocument | undefined;
      if (!doc) {
        reject(new Error("El documento no existe."));
        db.close();
        return;
      }
      doc.blob = blob;
      doc.sheetData = sheetData;
      doc.size = blob.size;
      doc.mimeType =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      doc.uploadedAt = new Date().toISOString();
      if (newName) doc.name = newName;
      const putReq = store.put(doc);
      putReq.onerror = () => reject(putReq.error);
      putReq.onsuccess = () => resolve();
      db.close();
    };
  });
}

/**
 * Obtiene los datos editables (sheetData) de un documento Excel.
 * Si el documento no tiene sheetData (porque se subió como archivo binario),
 * intenta leer el Blob con SheetJS para extraer los datos.
 */
export async function getDocumentSheet(
  id: string
): Promise<{ data: any[][]; name: string } | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(id);
    req.onerror = () => reject(req.error);
    req.onsuccess = async () => {
      const doc = req.result as StoredDocument | undefined;
      if (!doc) {
        resolve(null);
        db.close();
        return;
      }
      // Si ya tiene sheetData guardado, devolverlo
      if (doc.sheetData && doc.sheetData.length > 0) {
        resolve({ data: doc.sheetData, name: doc.name });
        db.close();
        return;
      }
      // Si no, intentar leer el Blob con SheetJS
      try {
        const XLSX = await import("xlsx");
        const arrayBuffer = await doc.blob.arrayBuffer();
        const wb = XLSX.read(arrayBuffer, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json<any[]>(ws, {
          header: 1,
          defval: "",
        });
        resolve({ data: data as any[][], name: doc.name });
      } catch (err) {
        reject(err);
      }
      db.close();
    };
  });
}

/**
 * Cuenta los documentos por proceso.
 * @returns Un mapa processId -> cantidad.
 */
export async function countDocumentsByProcess(): Promise<
  Record<string, number>
> {
  const all = await getAllDocuments();
  const counts: Record<string, number> = {};
  for (const doc of all) {
    counts[doc.processId] = (counts[doc.processId] || 0) + 1;
  }
  return counts;
}

/**
 * Convierte un documento almacenado en sus metadatos (sin el Blob).
 * Normaliza la categoría: si el documento no la tiene (datos antiguos),
 * se asigna la categoría por defecto "documentos".
 */
function toMetadata(doc: StoredDocument): DocumentMetadata {
  return {
    id: doc.id,
    processId: doc.processId,
    category: doc.category ?? DEFAULT_CATEGORY_ID,
    name: doc.name,
    size: doc.size,
    mimeType: doc.mimeType,
    uploadedAt: doc.uploadedAt,
    isEditableSheet:
      !!doc.sheetData ||
      doc.name.toLowerCase().endsWith(".xlsx") ||
      doc.name.toLowerCase().endsWith(".xls"),
  };
}
