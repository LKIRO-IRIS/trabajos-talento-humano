/**
 * Utilidades de exportación a PDF y Word para formatos editables.
 *
 * - PDF: usa jsPDF para generar un documento con la caja de calidad
 *   siguiendo normas APA (encabezado institucional, márgenes 2.54 cm,
 *   fuente Times New Roman 12, interlineado doble).
 * - Word: usa la librería docx para generar un .docx con la misma
 *   estructura.
 */

import { jsPDF } from "jspdf";
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  HeadingLevel,
  AlignmentType,
  BorderStyle,
  WidthType,
  PageNumber,
  Header,
  Footer,
} from "docx";
import type { EditableFormat } from "./format-store";
import { PROCESSES } from "./processes";

/** Información institucional para la caja de calidad */
const COMPANY = {
  name: "Detallitos con Amor",
  sub: "Gifting Studio",
  nit: "NIT: En trámite",
  city: "Colombia",
};

/**
 * Genera y descarga un PDF del formato con caja de calidad APA.
 */
export async function exportFormatToPDF(format: EditableFormat): Promise<void> {
  const pdf = new jsPDF({
    unit: "mm",
    format: "a4",
    orientation: "portrait",
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margin = 25.4; // 1 pulgada = 2.54 cm = 25.4 mm (norma APA)
  const contentWidth = pageWidth - margin * 2;

  // ===== CAJA DE CALIDAD (tabla institucional) =====
  // Estructura similar a la portada de documentos ICONTEC/APA:
  // +-----------------------+-----------------------+
  // | Logo + Empresa        | Código / Versión      |
  // |                       | Tipo / Fecha          |
  // +-----------------------+-----------------------+
  // | Título del documento (centrado, cruzando)     |
  // +-----------------------+-----------------------+
  // | Autor / Proceso       | Página / Total        |
  // +-----------------------+-----------------------+

  const process = PROCESSES.find((p) => p.id === format.processId);
  const boxTop = margin;
  const boxHeight = 40;
  const colWidth = contentWidth / 2;

  // Dibujar el contorno de la caja
  pdf.setDrawColor(63, 38, 32); // marrón oscuro
  pdf.setLineWidth(0.5);
  pdf.rect(margin, boxTop, contentWidth, boxHeight);

  // Línea vertical central (divide en 2 columnas) - solo en la fila superior
  pdf.line(margin + colWidth, boxTop, margin + colWidth, boxTop + 20);

  // Línea horizontal que divide la caja en 2 filas
  pdf.line(margin, boxTop + 20, margin + contentWidth, boxTop + 20);

  // Columna izquierda superior: empresa
  pdf.setFont("times", "bold");
  pdf.setFontSize(11);
  pdf.setTextColor(63, 38, 32);
  pdf.text(COMPANY.name, margin + 5, boxTop + 7);
  pdf.setFont("times", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(107, 74, 66);
  pdf.text(COMPANY.sub, margin + 5, boxTop + 12);
  pdf.text(COMPANY.nit, margin + 5, boxTop + 16);

  // Columna derecha superior: código y versión
  pdf.setFont("times", "bold");
  pdf.setFontSize(10);
  pdf.setTextColor(215, 6, 142); // rosa magenta
  pdf.text("Código:", margin + colWidth + 5, boxTop + 7);
  pdf.setTextColor(63, 38, 32);
  pdf.text(format.code, margin + colWidth + 25, boxTop + 7);

  pdf.setFont("times", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(107, 74, 66);
  pdf.text("Versión:", margin + colWidth + 5, boxTop + 12);
  pdf.text(format.version, margin + colWidth + 25, boxTop + 12);
  pdf.text("Tipo:", margin + colWidth + 5, boxTop + 16);
  pdf.text(format.documentType, margin + colWidth + 25, boxTop + 16);

  // Fila inferior: título centrado
  pdf.setFont("times", "bold");
  pdf.setFontSize(12);
  pdf.setTextColor(63, 38, 32);
  const titleLines = pdf.splitTextToSize(format.title, contentWidth - 10);
  pdf.text(titleLines, pageWidth / 2, boxTop + 27, { align: "center" });

  // Datos inferiores
  pdf.setFont("times", "normal");
  pdf.setFontSize(8);
  pdf.setTextColor(107, 74, 66);
  const fecha = new Date(format.modifiedAt).toLocaleDateString("es-CO");
  pdf.text(`Proceso: ${process?.name ?? ""}`, margin + 5, boxTop + 36);
  pdf.text(`Autor: ${format.author || "—"}`, margin + colWidth + 5, boxTop + 36);

  // ===== CUERPO DEL DOCUMENTO (normas APA) =====
  // Fuente Times New Roman 12, interlineado doble, sangría primera línea
  let y = boxTop + boxHeight + 10;

  pdf.setFont("times", "normal");
  pdf.setFontSize(12);
  pdf.setTextColor(31, 20, 16);
  const lineHeight = 7; // ~interlineado doble para 12pt

  for (const section of format.sections) {
    // Encabezado de sección (negrita, izquierda)
    if (y > pageHeight - margin - 10) {
      pdf.addPage();
      y = margin;
    }
    pdf.setFont("times", "bold");
    pdf.setFontSize(12);
    pdf.text(section.heading, margin, y);
    y += lineHeight + 2;

    // Cuerpo de la sección (justificado, con sangría)
    pdf.setFont("times", "normal");
    pdf.setFontSize(12);
    const bodyLines = pdf.splitTextToSize(section.body, contentWidth);
    for (let i = 0; i < bodyLines.length; i++) {
      if (y > pageHeight - margin - 10) {
        pdf.addPage();
        y = margin;
      }
      const indent = i === 0 ? 7 : 0; // sangría primera línea
      pdf.text(bodyLines[i], margin + indent, y, {
        align: "justify",
        maxWidth: contentWidth,
      });
      y += lineHeight;
    }
    y += 6;
  }

  // ===== PIE DE PÁGINA con numeración APA =====
  const pageCount = pdf.getNumberOfPages();
  for (let i = 0; i < pageCount; i++) {
    pdf.setPage(i + 1);
    pdf.setFont("times", "normal");
    pdf.setFontSize(9);
    pdf.setTextColor(107, 74, 66);
    pdf.text(
      `${i + 1} / ${pageCount}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: "center" }
    );
  }

  // Guardar el archivo
  pdf.save(`${format.code} - ${format.title}.pdf`);
}

/**
 * Genera y descarga un documento Word (.docx) del formato con caja de calidad.
 */
export async function exportFormatToWord(format: EditableFormat): Promise<void> {
  const process = PROCESSES.find((p) => p.id === format.processId);
  const fecha = new Date(format.modifiedAt).toLocaleDateString("es-CO");

  // Tabla de la caja de calidad (3 filas x 2 columnas)
  const headerTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
      bottom: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
      left: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
      right: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
      insideVertical: { style: BorderStyle.SINGLE, size: 1, color: "3F2620" },
    },
    rows: [
      // Fila 1: empresa | código/versión
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: COMPANY.name,
                    bold: true,
                    size: 22,
                    color: "3F2620",
                  }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({
                    text: COMPANY.sub,
                    size: 18,
                    color: "6B4A42",
                  }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({
                    text: COMPANY.nit,
                    size: 18,
                    color: "6B4A42",
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: "Código: ", bold: true, size: 20, color: "D7068E" }),
                  new TextRun({ text: format.code, bold: true, size: 20, color: "3F2620" }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({ text: "Versión: ", size: 18, color: "6B4A42" }),
                  new TextRun({ text: format.version, size: 18, color: "6B4A42" }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({ text: "Tipo: ", size: 18, color: "6B4A42" }),
                  new TextRun({ text: format.documentType, size: 18, color: "6B4A42" }),
                ],
              }),
            ],
          }),
        ],
      }),
      // Fila 2: título centrado (colSpan 2)
      new TableRow({
        children: [
          new TableCell({
            columnSpan: 2,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: format.title,
                    bold: true,
                    size: 26,
                    color: "3F2620",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      // Fila 3: proceso | autor/fecha
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: "Proceso: ", size: 18, color: "6B4A42" }),
                  new TextRun({
                    text: process?.name ?? "",
                    size: 18,
                    color: "3F2620",
                    bold: true,
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: "Autor: ", size: 18, color: "6B4A42" }),
                  new TextRun({
                    text: format.author || "—",
                    size: 18,
                    color: "3F2620",
                  }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({ text: "Fecha: ", size: 18, color: "6B4A42" }),
                  new TextRun({ text: fecha, size: 18, color: "3F2620" }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  // Secciones del cuerpo
  const bodyParagraphs: Paragraph[] = [
    headerTable as unknown as Paragraph,
    new Paragraph({ children: [new TextRun({ text: "" })] }),
  ];

  for (const section of format.sections) {
    bodyParagraphs.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [
          new TextRun({
            text: section.heading,
            bold: true,
            size: 24,
            color: "3F2620",
          }),
        ],
      })
    );
    // Dividir el cuerpo en párrafos
    const paragraphs = section.body.split(/\n\n+/);
    for (const p of paragraphs) {
      bodyParagraphs.push(
        new Paragraph({
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 480, after: 200 }, // interlineado doble
          indent: { firstLine: 720 }, // sangría 0.5"
          children: [
            new TextRun({
              text: p,
              size: 24, // 12pt
              color: "1F1410",
              font: "Times New Roman",
            }),
          ],
        })
      );
    }
    bodyParagraphs.push(new Paragraph({ children: [new TextRun({ text: "" })] }));
  }

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Times New Roman",
            size: 24,
          },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1440, // 1" = 1440 twips
              right: 1440,
              bottom: 1440,
              left: 1440,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({
                    text: `${COMPANY.name} · ${format.code}`,
                    size: 18,
                    color: "6B4A42",
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    size: 18,
                    color: "6B4A42",
                  }),
                  new TextRun({
                    text: " / ",
                    size: 18,
                    color: "6B4A42",
                  }),
                  new TextRun({
                    children: [PageNumber.TOTAL_PAGES],
                    size: 18,
                    color: "6B4A42",
                  }),
                ],
              }),
            ],
          }),
        },
        children: bodyParagraphs,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${format.code} - ${format.title}.docx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
