/**
 * Tipos y configuración de los procesos de Talento Humano
 * de Detallitos con Amor · Gifting Studio.
 * Define las siete carpetas principales del sistema de gestión documental.
 */

import {
  UserPlus,
  UserCheck,
  FileSignature,
  BookOpen,
  GraduationCap,
  ClipboardCheck,
  HeartHandshake,
  Files,
  ClipboardList,
  FileSpreadsheet,
  LayoutTemplate,
  type LucideIcon,
} from "lucide-react";

export interface ProcessInfo {
  /** Identificador único del proceso (usado como clave en el almacenamiento) */
  id: string;
  /** Nombre visible del proceso */
  name: string;
  /** Descripción corta del proceso */
  description: string;
  /** Ícono representativo del proceso */
  icon: LucideIcon;
  /** Color de acento del proceso (Tailwind) */
  accent: string;
  /** Color de fondo suave del proceso (Tailwind) */
  soft: string;
}

export interface CategoryInfo {
  /** Identificador único de la categoría */
  id: string;
  /** Nombre visible */
  name: string;
  /** Descripción del tipo de archivos que pertenecen a esta categoría */
  description: string;
  /** Ícono representativo */
  icon: LucideIcon;
  /** Color de acento (Tailwind) */
  accent: string;
  /** Color de fondo suave (Tailwind) */
  soft: string;
  /** Color del badge (Tailwind) */
  badge: string;
}

/**
 * Las cuatro categorías de clasificación documental dentro de cada proceso.
 *
 * - Modelos: documentos de referencia o ejemplos ya diligenciados.
 * - Registros: evidencias de ejecución (actas, constancias, listados, firmas).
 * - Formatos: plantillas en blanco listas para diligenciar.
 * - Documentos: manuales, políticas, procedimientos y material informativo.
 */
export const CATEGORIES: CategoryInfo[] = [
  {
    id: "modelos",
    name: "Modelos",
    description:
      "Documentos de referencia o ejemplos ya diligenciados que sirven de guía.",
    icon: LayoutTemplate,
    accent: "text-[#D7068E]",
    soft: "bg-[#D7068E]/10",
    badge: "bg-[#D7068E]/15 text-[#D7068E] border-[#D7068E]/30",
  },
  {
    id: "registros",
    name: "Registros",
    description:
      "Evidencias de ejecución: actas, constancias, listados de asistencia y firmas.",
    icon: ClipboardList,
    accent: "text-[#6B4A42]",
    soft: "bg-[#6B4A42]/10",
    badge: "bg-[#6B4A42]/15 text-[#6B4A42] border-[#6B4A42]/30",
  },
  {
    id: "formatos",
    name: "Formatos",
    description:
      "Plantillas y formularios en blanco listos para ser diligenciados.",
    icon: FileSpreadsheet,
    accent: "text-[#B58A1A]",
    soft: "bg-[#FFD24B]/20",
    badge: "bg-[#FFD24B]/25 text-[#8A6510] border-[#FFD24B]/40",
  },
  {
    id: "documentos",
    name: "Documentos",
    description:
      "Manuales, políticas, procedimientos y material informativo general.",
    icon: Files,
    accent: "text-[#3F2620]",
    soft: "bg-[#3F2620]/10",
    badge: "bg-[#3F2620]/10 text-[#3F2620] border-[#3F2620]/25",
  },
];

/** ID de la categoría por defecto para archivos antiguos sin clasificación */
export const DEFAULT_CATEGORY_ID = "documentos";

/**
 * Obtiene la información de una categoría por su id.
 * Devuelve la categoría "Documentos" si no se encuentra.
 */
export function getCategoryInfo(categoryId: string | undefined): CategoryInfo {
  if (!categoryId) {
    return CATEGORIES.find((c) => c.id === DEFAULT_CATEGORY_ID) ?? CATEGORIES[0];
  }
  return (
    CATEGORIES.find((c) => c.id === categoryId) ??
    CATEGORIES.find((c) => c.id === DEFAULT_CATEGORY_ID) ??
    CATEGORIES[0]
  );
}

/**
 * Los siete procesos principales de Talento Humano.
 * Cada proceso se representa como una carpeta en el explorador documental.
 * Se mantienen los nombres originales del prompt, con la paleta de
 * Detallitos con Amor (rosa, dorado, marrón).
 */
export const PROCESSES: ProcessInfo[] = [
  {
    id: "reclutamiento",
    name: "Reclutamiento",
    description:
      "Convocatorias, fuentes de candidatos y hojas de vida recibidas para los procesos de búsqueda de talento.",
    icon: UserPlus,
    accent: "text-[#D7068E]",
    soft: "bg-[#D7068E]/10",
  },
  {
    id: "seleccion",
    name: "Selección",
    description:
      "Pruebas técnicas, psicométricas, entrevistas y resultados de evaluación de candidatos.",
    icon: UserCheck,
    accent: "text-[#6B4A42]",
    soft: "bg-[#6B4A42]/10",
  },
  {
    id: "vinculacion",
    name: "Vinculación",
    description:
      "Contratos de trabajo, afiliaciones a seguridad social y documentación legal de ingreso.",
    icon: FileSignature,
    accent: "text-[#B58A1A]",
    soft: "bg-[#FFD24B]/20",
  },
  {
    id: "induccion",
    name: "Inducción",
    description:
      "Manuales de bienvenida, presentaciones institucionales y actas de inducción al cargo.",
    icon: BookOpen,
    accent: "text-[#D7068E]",
    soft: "bg-[#D7068E]/10",
  },
  {
    id: "capacitacion",
    name: "Capacitación",
    description:
      "Planes de formación, materiales de capacitación y constancias de cursos realizados.",
    icon: GraduationCap,
    accent: "text-[#6B4A42]",
    soft: "bg-[#6B4A42]/10",
  },
  {
    id: "evaluacion",
    name: "Evaluación del desempeño",
    description:
      "Formatos de evaluación, planes de mejora y reportes de resultados por periodo.",
    icon: ClipboardCheck,
    accent: "text-[#B58A1A]",
    soft: "bg-[#FFD24B]/20",
  },
  {
    id: "bienestar",
    name: "Bienestar laboral",
    description:
      "Actividades de bienestar, reconocimientos, encuestas de clima y programas de beneficio.",
    icon: HeartHandshake,
    accent: "text-[#D7068E]",
    soft: "bg-[#D7068E]/10",
  },
];

/**
 * Extensiones de archivo permitidas en el sistema.
 * Cubre PDF, Word, Excel, PowerPoint e imágenes.
 */
export const ALLOWED_EXTENSIONS = [
  ".pdf",
  ".doc",
  ".docx",
  ".xls",
  ".xlsx",
  ".ppt",
  ".pptx",
  ".jpg",
  ".jpeg",
  ".png",
  ".gif",
  ".webp",
];

/**
 * Etiquetas legibles para cada tipo de archivo.
 */
export const FILE_TYPE_LABELS: Record<string, string> = {
  pdf: "PDF",
  doc: "Word",
  docx: "Word",
  xls: "Excel",
  xlsx: "Excel",
  ppt: "PowerPoint",
  pptx: "PowerPoint",
  jpg: "Imagen",
  jpeg: "Imagen",
  png: "Imagen",
  gif: "Imagen",
  webp: "Imagen",
};

/**
 * Colores (Tailwind) para diferenciar los tipos de archivo visualmente.
 */
export const FILE_TYPE_COLORS: Record<string, string> = {
  pdf: "bg-red-100 text-red-700 border-red-200",
  doc: "bg-blue-100 text-blue-700 border-blue-200",
  docx: "bg-blue-100 text-blue-700 border-blue-200",
  xls: "bg-green-100 text-green-700 border-green-200",
  xlsx: "bg-green-100 text-green-700 border-green-200",
  ppt: "bg-orange-100 text-orange-700 border-orange-200",
  pptx: "bg-orange-100 text-orange-700 border-orange-200",
  jpg: "bg-purple-100 text-purple-700 border-purple-200",
  jpeg: "bg-purple-100 text-purple-700 border-purple-200",
  png: "bg-purple-100 text-purple-700 border-purple-200",
  gif: "bg-purple-100 text-purple-700 border-purple-200",
  webp: "bg-purple-100 text-purple-700 border-purple-200",
};

/**
 * Obtiene la extensión de un nombre de archivo (en minúsculas, sin el punto).
 */
export function getFileExtension(filename: string): string {
  const idx = filename.lastIndexOf(".");
  if (idx === -1 || idx === 0) return "";
  return filename.slice(idx + 1).toLowerCase();
}

/**
 * Valida si un archivo tiene una extensión permitida.
 */
export function isFileAllowed(filename: string): boolean {
  const ext = getFileExtension(filename);
  return ALLOWED_EXTENSIONS.includes(`.${ext}`);
}

/**
 * Devuelve una etiqueta legible para el tipo de archivo.
 */
export function getFileTypeLabel(filename: string): string {
  const ext = getFileExtension(filename);
  return FILE_TYPE_LABELS[ext] ?? "Archivo";
}

/**
 * Devuelve las clases Tailwind para el badge del tipo de archivo.
 */
export function getFileTypeColor(filename: string): string {
  const ext = getFileExtension(filename);
  return FILE_TYPE_COLORS[ext] ?? "bg-gray-100 text-gray-700 border-gray-200";
}

/**
 * Formatea una fecha en formato legible en español.
 */
export function formatUploadDate(isoDate: string): string {
  try {
    const d = new Date(isoDate);
    return d.toLocaleString("es-CO", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return isoDate;
  }
}

/**
 * Formatea un tamaño de bytes a una cadena legible (KB, MB).
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
