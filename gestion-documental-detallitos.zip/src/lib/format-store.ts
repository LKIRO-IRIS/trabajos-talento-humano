/**
 * Almacenamiento de formatos editables y numeración consecutiva.
 *
 * Los formatos editables se guardan como JSON (no como Blob binario) en
 * un object store separado dentro de la misma base de datos IndexedDB.
 * Esto permite reabrirlos y seguir editándolos.
 *
 * La numeración consecutiva se guarda por proceso, con el formato:
 *   DCA-TH-{PROC}-{NNN}
 * donde PROC es la abreviatura del proceso y NNN es un contador de 3 dígitos.
 */

import { PROCESSES } from "./processes";

/** Estructura de un formato editable */
export interface EditableFormat {
  /** Identificador único */
  id: string;
  /** Proceso al que pertenece */
  processId: string;
  /** Categoría (siempre "formatos" para estos documentos) */
  category: "formatos";
  /** Código consecutivo, ej: DCA-TH-REC-001 */
  code: string;
  /** Título del documento */
  title: string;
  /** Tipo de documento (Acta, Formato, Manual, etc.) */
  documentType: string;
  /** Versión del documento */
  version: string;
  /** Autor o responsable */
  author: string;
  /** Fecha de creación ISO */
  createdAt: string;
  /** Fecha de última modificación ISO */
  modifiedAt: string;
  /**
   * Contenido estructurado del cuerpo del documento.
   * Se guarda como array de secciones, cada una con encabezado y párrafos.
   */
  sections: FormatSection[];
  /** Tipo MIME virtual para integración con el listado de archivos */
  mimeType: string;
  /** Tamaño aproximado en bytes (para mostrar en la UI) */
  size: number;
}

/** Sección de un formato editable */
export interface FormatSection {
  id: string;
  heading: string;
  body: string;
}

const DB_NAME = "human-talent-documents";
// Misma versión que document-store.ts (que crea todos los stores).
const DB_VERSION = 2;
const FORMAT_STORE = "editable-formats";
const COUNTER_STORE = "format-counters";

/**
 * Abre la base de datos IndexedDB.
 * Los stores los crea document-store.ts en su onupgradeneeded;
 * aquí solo abrimos la conexión.
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !("indexedDB" in window)) {
      reject(new Error("IndexedDB no está disponible en este entorno."));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      // Por si acaso se abre antes que document-store, crear los stores aquí también
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(FORMAT_STORE)) {
        const store = db.createObjectStore(FORMAT_STORE, { keyPath: "id" });
        store.createIndex("processId", "processId", { unique: false });
      }
      if (!db.objectStoreNames.contains(COUNTER_STORE)) {
        db.createObjectStore(COUNTER_STORE, { keyPath: "processId" });
      }
    };
  });
}

/**
 * Abreviaturas de los procesos para el código consecutivo.
 */
const PROCESS_ABBR: Record<string, string> = {
  reclutamiento: "REC",
  seleccion: "SEL",
  vinculacion: "VIN",
  induccion: "IND",
  capacitacion: "CAP",
  evaluacion: "EVA",
  bienestar: "BIE",
};

/**
 * Genera el siguiente código consecutivo para un proceso.
 * Formato: DCA-TH-{PROC}-{NNN}
 */
export async function generateNextCode(processId: string): Promise<string> {
  const db = await openDB();
  const abbr = PROCESS_ABBR[processId] ?? "GEN";
  return new Promise((resolve, reject) => {
    const tx = db.transaction(COUNTER_STORE, "readwrite");
    const store = tx.objectStore(COUNTER_STORE);
    const getReq = store.get(processId);
    getReq.onerror = () => reject(getReq.error);
    getReq.onsuccess = () => {
      const row = getReq.result as
        | { processId: string; counter: number }
        | undefined;
      const next = (row?.counter ?? 0) + 1;
      const putReq = store.put({ processId, counter: next });
      putReq.onerror = () => reject(putReq.error);
      putReq.onsuccess = () => {
        const code = `DCA-TH-${abbr}-${String(next).padStart(3, "0")}`;
        resolve(code);
        db.close();
      };
    };
  });
}

/**
 * Genera un identificador único para un formato.
 */
function generateId(): string {
  return `fmt_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * Guarda (crea o actualiza) un formato editable.
 */
export async function saveFormat(
  format: EditableFormat
): Promise<EditableFormat> {
  const db = await openDB();
  format.modifiedAt = new Date().toISOString();
  format.size = estimateSize(format);
  format.mimeType = "application/vnd.detallitos.formato";
  return new Promise((resolve, reject) => {
    const tx = db.transaction(FORMAT_STORE, "readwrite");
    const store = tx.objectStore(FORMAT_STORE);
    const req = store.put(format);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      resolve(format);
      db.close();
    };
  });
}

/**
 * Obtiene todos los formatos editables de un proceso.
 */
export async function getFormatsByProcess(
  processId: string
): Promise<EditableFormat[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(FORMAT_STORE, "readonly");
    const store = tx.objectStore(FORMAT_STORE);
    const index = store.index("processId");
    const req = index.getAll(processId);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const list = (req.result as EditableFormat[]) || [];
      list.sort(
        (a, b) =>
          new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()
      );
      resolve(list);
      db.close();
    };
  });
}

/**
 * Obtiene un formato editable por su id.
 */
export async function getFormat(id: string): Promise<EditableFormat | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(FORMAT_STORE, "readonly");
    const store = tx.objectStore(FORMAT_STORE);
    const req = store.get(id);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      resolve((req.result as EditableFormat) ?? null);
      db.close();
    };
  });
}

/**
 * Elimina un formato editable.
 */
export async function deleteFormat(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(FORMAT_STORE, "readwrite");
    const store = tx.objectStore(FORMAT_STORE);
    const req = store.delete(id);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      resolve();
      db.close();
    };
  });
}

/**
 * Crea un nuevo formato con valores por defecto y código consecutivo.
 */
export async function createNewFormat(
  processId: string
): Promise<EditableFormat> {
  const code = await generateNextCode(processId);
  const now = new Date().toISOString();
  return {
    id: generateId(),
    processId,
    category: "formatos",
    code,
    title: "Nuevo formato",
    documentType: "Formato",
    version: "1.0",
    author: "",
    createdAt: now,
    modifiedAt: now,
    sections: [
      {
        id: `sec_${Date.now()}`,
        heading: "Objetivo",
        body: "",
      },
      {
        id: `sec_${Date.now() + 1}`,
        heading: "Procedimiento",
        body: "",
      },
    ],
    mimeType: "application/vnd.detallitos.formato",
    size: 0,
  };
}

/**
 * Estima el tamaño en bytes de un formato (para mostrar en la UI).
 */
function estimateSize(format: EditableFormat): number {
  const json = JSON.stringify(format);
  return new Blob([json]).size;
}

/**
 * Convierte un formato editable a metadata compatible con el listado de archivos.
 */
export function formatToMetadata(f: EditableFormat) {
  return {
    id: f.id,
    processId: f.processId,
    category: f.category,
    name: `${f.code} - ${f.title}.dcafmt`,
    size: f.size,
    mimeType: f.mimeType,
    uploadedAt: f.modifiedAt,
    isEditable: true,
  };
}

/**
 * Verifica si un nombre corresponde a un formato editable.
 */
export function isEditableFormatName(name: string): boolean {
  return name.endsWith(".dcafmt");
}
