"use client";

/**
 * Encabezado superior de la aplicación Detallitos con Amor.
 * Muestra el logo, el nombre de la empresa, el título del sistema,
 * el buscador general de documentos y un botón para abrir el sidebar en móvil.
 */

import { Menu, Search, Bell, UserCircle2 } from "lucide-react";
import Image from "next/image";
import { Input } from "@/components/ui/input";

interface HeaderProps {
  /** Consulta actual del buscador general */
  searchQuery: string;
  /** Callback al cambiar el buscador */
  onSearchChange: (query: string) => void;
  /** Callback para abrir el sidebar en móvil */
  onOpenSidebar: () => void;
  /** Indica si el buscador debe estar visible (solo en vista principal) */
  showGlobalSearch: boolean;
}

export function Header({
  searchQuery,
  onSearchChange,
  onOpenSidebar,
  showGlobalSearch,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-[#F0E4D8] bg-[#FFFBF7]/90 px-4 shadow-sm backdrop-blur-md lg:px-6">
      {/* Botón menú (solo móvil) */}
      <button
        type="button"
        onClick={onOpenSidebar}
        className="rounded-md p-2 text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#D7068E] lg:hidden"
        aria-label="Abrir menú"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Logo y título corporativo */}
      <div className="flex items-center gap-3">
        {/* Logo visible desde sm */}
        <div className="relative h-9 w-9 overflow-hidden rounded-full ring-2 ring-[#D7068E]/30 sm:flex sm:items-center sm:justify-center">
          <Image
            src="/logo-dca.jpeg"
            alt="Detallitos con Amor"
            fill
            sizes="36px"
            className="object-cover"
            priority
          />
        </div>
        <div className="leading-tight">
          <h1 className="text-base font-bold text-[#3F2620] sm:text-lg">
            Detallitos con Amor
          </h1>
          <p className="hidden text-xs font-medium text-[#D7068E] sm:block">
            Gifting Studio · Gestión Documental
          </p>
        </div>
      </div>

      {/* Buscador general de documentos */}
      {showGlobalSearch && (
        <div className="ml-auto hidden max-w-md flex-1 items-center md:flex">
          <div className="relative w-full">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B4A42]/60" />
            <Input
              type="search"
              placeholder="Buscar archivos por nombre..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full border-[#F0E4D8] bg-[#FFF4EA] pl-9 text-[#3F2620] placeholder:text-[#6B4A42]/60 focus-visible:border-[#D7068E] focus-visible:ring-[#D7068E]/30"
              aria-label="Buscar archivos por nombre"
            />
          </div>
        </div>
      )}

      {/* Acciones a la derecha */}
      <div className="ml-auto flex items-center gap-2 md:ml-3">
        {/* Buscador compacto en móvil */}
        {showGlobalSearch && (
          <button
            type="button"
            className="rounded-md p-2 text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#D7068E] md:hidden"
            aria-label="Buscar archivos"
            onClick={() => {
              const q = window.prompt("Buscar archivos por nombre:");
              if (q !== null) onSearchChange(q);
            }}
          >
            <Search className="h-5 w-5" />
          </button>
        )}
        <button
          type="button"
          className="hidden rounded-md p-2 text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#D7068E] sm:block"
          aria-label="Notificaciones"
        >
          <Bell className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2 rounded-full border border-[#F0E4D8] bg-[#FFF4EA] px-2 py-1 sm:px-3">
          <UserCircle2 className="h-6 w-6 text-[#D7068E]" />
          <div className="hidden text-xs leading-tight sm:block">
            <p className="font-semibold text-[#3F2620]">Bienvenida</p>
            <p className="text-[#6B4A42]">Equipo DCA</p>
          </div>
        </div>
      </div>
    </header>
  );
}
