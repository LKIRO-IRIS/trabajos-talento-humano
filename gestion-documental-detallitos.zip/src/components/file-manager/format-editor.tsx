"use client";

/**
 * Editor de formatos editables.
 *
 * Permite crear y modificar formatos con:
 * - Caja de calidad con datos institucionales (normas APA)
 * - Numeración consecutiva automática (DCA-TH-PROC-NNN)
 * - Secciones editables con encabezado y cuerpo
 * - Exportación a PDF y Word
 */

import { useEffect, useState } from "react";
import {
  Save,
  FileText,
  Plus,
  Trash2,
  Download,
  FileType2,
  X,
  Loader2,
  Eye,
  Edit3,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import type { EditableFormat, FormatSection } from "@/lib/format-store";
import type { ProcessInfo } from "@/lib/processes";
import { PROCESSES } from "@/lib/processes";
import { exportFormatToPDF, exportFormatToWord } from "@/lib/format-export";
import { cn } from "@/lib/utils";

interface FormatEditorProps {
  open: boolean;
  /** Formato a editar (null si es nuevo) */
  format: EditableFormat | null;
  /** Proceso al que pertenece */
  process: ProcessInfo;
  /** Callback al guardar */
  onSave: (format: EditableFormat) => Promise<void>;
  /** Callback al cerrar */
  onClose: () => void;
}

export function FormatEditor({
  open,
  format,
  process,
  onSave,
  onClose,
}: FormatEditorProps) {
  const [draft, setDraft] = useState<EditableFormat | null>(format);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState<"pdf" | "word" | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    setDraft(format);
    setPreviewMode(false);
  }, [format, open]);

  if (!draft) return null;

  const update = (patch: Partial<EditableFormat>) =>
    setDraft({ ...draft, ...patch });

  const updateSection = (id: string, patch: Partial<FormatSection>) =>
    setDraft({
      ...draft,
      sections: draft.sections.map((s) =>
        s.id === id ? { ...s, ...patch } : s
      ),
    });

  const addSection = () =>
    setDraft({
      ...draft,
      sections: [
        ...draft.sections,
        {
          id: `sec_${Date.now()}`,
          heading: "Nueva sección",
          body: "",
        },
      ],
    });

  const removeSection = (id: string) =>
    setDraft({
      ...draft,
      sections: draft.sections.filter((s) => s.id !== id),
    });

  const handleSave = async () => {
    if (!draft) return;
    setSaving(true);
    try {
      await onSave(draft);
    } finally {
      setSaving(false);
    }
  };

  const handleExportPDF = async () => {
    if (!draft) return;
    setExporting("pdf");
    try {
      await exportFormatToPDF(draft);
    } finally {
      setExporting(null);
    }
  };

  const handleExportWord = async () => {
    if (!draft) return;
    setExporting("word");
    try {
      await exportFormatToWord(draft);
    } finally {
      setExporting(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] w-[95vw] max-w-5xl overflow-hidden p-0">
        {/* Barra superior del editor */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F0E4D8] bg-[#FFF4EA] px-4 py-3">
          <div className="flex items-center gap-2">
            <FileType2 className="h-5 w-5 text-[#D7068E]" />
            <div>
              <p className="text-sm font-bold text-[#3F2620]">
                Editor de formato
              </p>
              <p className="text-xs text-[#6B4A42]">
                {process.name} · {draft.code}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle preview/edit */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setPreviewMode(!previewMode)}
              className="border-[#F0E4D8] text-[#6B4A42]"
            >
              {previewMode ? (
                <>
                  <Edit3 className="mr-1.5 h-4 w-4" />
                  Editar
                </>
              ) : (
                <>
                  <Eye className="mr-1.5 h-4 w-4" />
                  Vista previa
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleExportPDF}
              disabled={exporting !== null}
              className="border-[#D7068E]/30 text-[#D7068E]"
            >
              {exporting === "pdf" ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-1.5 h-4 w-4" />
              )}
              PDF
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleExportWord}
              disabled={exporting !== null}
              className="border-[#B58A1A]/40 text-[#B58A1A]"
            >
              {exporting === "word" ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-1.5 h-4 w-4" />
              )}
              Word
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={handleSave}
              disabled={saving}
              className="bg-[#D7068E] text-white hover:bg-[#D7068E]/90"
            >
              {saving ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-1.5 h-4 w-4" />
              )}
              Guardar
            </Button>
          </div>
        </div>

        <div className="max-h-[80vh] overflow-y-auto px-4 py-4 sm:px-6">
          {previewMode ? (
            <PreviewMode format={draft} process={process} />
          ) : (
            <EditMode
              draft={draft}
              process={process}
              update={update}
              updateSection={updateSection}
              addSection={addSection}
              removeSection={removeSection}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Modo edición: campos editables.
 */
function EditMode({
  draft,
  process,
  update,
  updateSection,
  addSection,
  removeSection,
}: {
  draft: EditableFormat;
  process: ProcessInfo;
  update: (patch: Partial<EditableFormat>) => void;
  updateSection: (id: string, patch: Partial<FormatSection>) => void;
  addSection: () => void;
  removeSection: (id: string) => void;
}) {
  return (
    <div className="space-y-5">
      {/* ===== CAJA DE CALIDAD (datos editables) ===== */}
      <section className="rounded-xl border-2 border-[#D7068E]/30 bg-[#FFF4EA] p-4">
        <div className="mb-3 flex items-center gap-2">
          <FileText className="h-4 w-4 text-[#D7068E]" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#D7068E]">
            Caja de calidad · Normas APA
          </h3>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Código consecutivo
            </Label>
            <Input
              value={draft.code}
              readOnly
              className="bg-white font-mono text-sm font-bold text-[#D7068E]"
            />
            <p className="text-[11px] text-[#6B4A42]/70">
              Generado automáticamente por proceso
            </p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Título del documento
            </Label>
            <Input
              value={draft.title}
              onChange={(e) => update({ title: e.target.value })}
              placeholder="Ej: Formato de solicitud de empleo"
              className="bg-white text-[#3F2620]"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Tipo de documento
            </Label>
            <Input
              value={draft.documentType}
              onChange={(e) => update({ documentType: e.target.value })}
              placeholder="Ej: Formato, Acta, Manual, Procedimiento"
              className="bg-white text-[#3F2620]"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Versión
            </Label>
            <Input
              value={draft.version}
              onChange={(e) => update({ version: e.target.value })}
              placeholder="1.0"
              className="bg-white text-[#3F2620]"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Autor / Responsable
            </Label>
            <Input
              value={draft.author}
              onChange={(e) => update({ author: e.target.value })}
              placeholder="Nombre del responsable"
              className="bg-white text-[#3F2620]"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-[#6B4A42]">
              Proceso
            </Label>
            <Input
              value={process.name}
              readOnly
              className="bg-white text-[#3F2620]"
            />
          </div>
        </div>
      </section>

      {/* ===== SECCIONES DEL CUERPO ===== */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#3F2620]">
            Contenido del documento
          </h3>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addSection}
            className="border-[#D7068E]/30 text-[#D7068E]"
          >
            <Plus className="mr-1.5 h-4 w-4" />
            Sección
          </Button>
        </div>

        {draft.sections.map((section, idx) => (
          <div
            key={section.id}
            className="rounded-lg border border-[#F0E4D8] bg-white p-3"
          >
            <div className="mb-2 flex items-center gap-2">
              <span className="rounded bg-[#D7068E]/10 px-2 py-0.5 text-xs font-bold text-[#D7068E]">
                {idx + 1}
              </span>
              <Input
                value={section.heading}
                onChange={(e) =>
                  updateSection(section.id, { heading: e.target.value })
                }
                placeholder="Encabezado de la sección"
                className="border-transparent bg-transparent px-1 font-semibold text-[#3F2620] hover:border-[#F0E4D8] focus-visible:border-[#D7068E]"
              />
              <button
                type="button"
                onClick={() => removeSection(section.id)}
                className="rounded p-1 text-[#6B4A42]/60 hover:bg-red-50 hover:text-red-600"
                aria-label="Eliminar sección"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
            <Textarea
              value={section.body}
              onChange={(e) =>
                updateSection(section.id, { body: e.target.value })
              }
              placeholder="Escriba aquí el contenido de esta sección..."
              className="min-h-[100px] resize-y border-[#F0E4D8] bg-[#FFFBF7] text-sm text-[#3F2620] focus-visible:border-[#D7068E]"
            />
          </div>
        ))}
      </section>
    </div>
  );
}

/**
 * Vista previa: muestra cómo se verá el documento exportado.
 */
function PreviewMode({
  format,
  process,
}: {
  format: EditableFormat;
  process: ProcessInfo;
}) {
  const fecha = new Date(format.modifiedAt).toLocaleDateString("es-CO");
  return (
    <div className="mx-auto max-w-3xl rounded-lg bg-white p-8 shadow-sm">
      {/* Caja de calidad */}
      <div className="mb-6 border-2 border-[#3F2620]">
        <table className="w-full text-sm">
          <tbody>
            <tr>
              <td className="border-r border-[#3F2620] p-3 align-top">
                <p className="font-bold text-[#3F2620]">
                  Detallitos con Amor
                </p>
                <p className="text-xs text-[#6B4A42]">Gifting Studio</p>
                <p className="text-xs text-[#6B4A42]">Colombia</p>
              </td>
              <td className="p-3 align-top">
                <p className="text-xs">
                  <span className="font-bold text-[#D7068E]">Código: </span>
                  <span className="font-bold text-[#3F2620]">{format.code}</span>
                </p>
                <p className="text-xs text-[#6B4A42]">
                  Versión: {format.version}
                </p>
                <p className="text-xs text-[#6B4A42]">
                  Tipo: {format.documentType}
                </p>
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="border-t border-[#3F2620] p-3 text-center">
                <p className="text-lg font-bold text-[#3F2620]">
                  {format.title}
                </p>
              </td>
            </tr>
            <tr>
              <td className="border-t border-[#3F2620] p-3 text-xs text-[#6B4A42]">
                Proceso: <span className="font-semibold text-[#3F2620]">{process.name}</span>
              </td>
              <td className="border-t border-l border-[#3F2620] p-3 text-xs text-[#6B4A42]">
                Autor: {format.author || "—"} · {fecha}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Cuerpo */}
      <div className="space-y-4">
        {format.sections.map((section) => (
          <div key={section.id}>
            <h3 className="mb-1 font-bold text-[#3F2620]">
              {section.heading}
            </h3>
            <div className="whitespace-pre-wrap text-sm text-[#1F1410]">
              {section.body || (
                <span className="text-[#6B4A42]/50 italic">
                  (Sin contenido)
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Pie */}
      <div className="mt-8 border-t border-[#F0E4D8] pt-2 text-center text-xs text-[#6B4A42]">
        Documento confidencial · Detallitos con Amor · {format.code}
      </div>
    </div>
  );
}
