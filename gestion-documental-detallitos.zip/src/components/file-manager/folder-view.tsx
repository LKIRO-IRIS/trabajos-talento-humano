"use client";

/**
 * Vista de carpeta individual.
 * Muestra los documentos de un proceso específico organizados por categoría
 * (Modelos, Registros, Formatos, Documentos) y permite:
 * - Subir documentos desde el computador, clasificándolos en una categoría.
 * - Buscar documentos por nombre dentro de la carpeta.
 * - Filtrar por categoría mediante pestañas.
 * - Descargar y eliminar documentos.
 * - Regresar a la vista principal.
 */

import { useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Upload,
  Search,
  Download,
  Trash2,
  FileText,
  FolderOpen,
  Loader2,
  AlertCircle,
  Layers,
  Plus,
  Edit3,
  FileSpreadsheet,
  FileType2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { ProcessInfo, CategoryInfo } from "@/lib/processes";
import {
  CATEGORIES,
  getCategoryInfo,
  getFileTypeColor,
  getFileTypeLabel,
  formatUploadDate,
  formatFileSize,
} from "@/lib/processes";
import type { DocumentMetadata } from "@/lib/document-store";
import type { EditableFormat } from "@/lib/format-store";
import { FormatEditor } from "./format-editor";
import { ExcelEditor } from "./excel-editor";
import { cn } from "@/lib/utils";

interface FolderViewProps {
  /** Información del proceso actual */
  process: ProcessInfo;
  /** Documentos actualmente cargados en la carpeta */
  documents: DocumentMetadata[];
  /** Consulta del buscador interno */
  searchQuery: string;
  /** Callback al cambiar la búsqueda */
  onSearchChange: (q: string) => void;
  /** Callback para regresar al panel principal */
  onBack: () => void;
  /**
   * Callback para subir archivos.
   * Recibe los archivos y la categoría en la que se deben clasificar.
   */
  onUpload: (files: File[], category: string) => Promise<void>;
  /** Callback para descargar un documento */
  onDownload: (id: string) => Promise<void>;
  /** Callback para eliminar un documento */
  onDelete: (id: string) => Promise<void>;
  /** Indica si hay una operación de subida en curso */
  uploading: boolean;
  /** Callback para crear un nuevo formato editable */
  onCreateFormat: () => Promise<EditableFormat | null>;
  /** Callback para abrir un formato existente */
  onOpenFormat: (formatId: string) => Promise<EditableFormat | null>;
  /** Callback para guardar un formato editado */
  onSaveFormat: (format: EditableFormat) => Promise<void>;
  /** Callback para abrir un Excel en el editor */
  onOpenSheet: (docId: string) => Promise<{ data: any[][]; name: string } | null>;
  /** Callback para guardar los datos editados de un Excel */
  onSaveSheet: (docId: string, data: any[][], name: string) => Promise<void>;
}

/** Valor especial para la pestaña "Todos" */
const ALL_TAB = "all";

export function FolderView({
  process,
  documents,
  searchQuery,
  onSearchChange,
  onBack,
  onUpload,
  onDownload,
  onDelete,
  uploading,
  onCreateFormat,
  onOpenFormat,
  onSaveFormat,
  onOpenSheet,
  onSaveSheet,
}: FolderViewProps) {
  const Icon = process.icon;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [pendingDelete, setPendingDelete] = useState<DocumentMetadata | null>(
    null
  );
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // Pestaña de categoría activa ("all" = ver todas)
  const [activeCategory, setActiveCategory] = useState<string>(ALL_TAB);

  // Archivos pendientes de clasificar (seleccionados o arrastrados)
  const [pendingFiles, setPendingFiles] = useState<File[] | null>(null);
  // Categoría seleccionada en el diálogo de subida
  const [selectedCategory, setSelectedCategory] = useState<string>(
    CATEGORIES[3].id // "documentos" por defecto
  );

  // Estado del editor de formatos
  const [editingFormat, setEditingFormat] = useState<EditableFormat | null>(null);
  const [formatEditorOpen, setFormatEditorOpen] = useState(false);
  const [creatingFormat, setCreatingFormat] = useState(false);

  // Estado del editor de Excel
  const [excelOpen, setExcelOpen] = useState(false);
  const [excelData, setExcelData] = useState<any[][]>([[""]]);
  const [excelName, setExcelName] = useState("");
  const [excelDocId, setExcelDocId] = useState<string | null>(null);
  const [openingSheet, setOpeningSheet] = useState<string | null>(null);

  /**
   * Conteo de documentos por categoría dentro de esta carpeta.
   */
  const countsByCategory = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const c of CATEGORIES) counts[c.id] = 0;
    for (const doc of documents) {
      const cat = doc.category ?? "documentos";
      counts[cat] = (counts[cat] || 0) + 1;
    }
    return counts;
  }, [documents]);

  /**
   * Documentos filtrados por la pestaña de categoría activa
   * y por la búsqueda interna por nombre.
   */
  const filtered = useMemo(() => {
    let list = documents;
    if (activeCategory !== ALL_TAB) {
      list = list.filter((d) => (d.category ?? "documentos") === activeCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(q));
    }
    return list;
  }, [documents, activeCategory, searchQuery]);

  /**
   * Abre el diálogo de selección de categoría tras elegir archivos.
   * Si la pestaña activa es una categoría concreta, la preselecciona.
   */
  const openCategoryDialog = (files: File[]) => {
    if (files.length === 0) return;
    if (activeCategory !== ALL_TAB) {
      setSelectedCategory(activeCategory);
    }
    setPendingFiles(files);
  };

  /**
   * Maneja la selección de archivos desde el input.
   */
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length > 0) openCategoryDialog(files);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  /**
   * Maneja archivos soltados en la zona de arrastre.
   */
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) openCategoryDialog(files);
  };

  /**
   * Confirma la subida con la categoría seleccionada.
   */
  const confirmUpload = async () => {
    if (!pendingFiles || pendingFiles.length === 0) return;
    const files = pendingFiles;
    const category = selectedCategory;
    setPendingFiles(null);
    await onUpload(files, category);
  };

  /**
   * Descarga un documento con feedback visual.
   */
  const handleDownload = async (id: string) => {
    setDownloadingId(id);
    try {
      await onDownload(id);
    } finally {
      setDownloadingId(null);
    }
  };

  /**
   * Elimina un documento con confirmación previa.
   */
  const handleDelete = async () => {
    if (!pendingDelete) return;
    setDeletingId(pendingDelete.id);
    try {
      await onDelete(pendingDelete.id);
    } finally {
      setDeletingId(null);
      setPendingDelete(null);
    }
  };

  /**
   * Crea un nuevo formato editable y abre el editor.
   */
  const handleNewFormat = async () => {
    setCreatingFormat(true);
    try {
      const fmt = await onCreateFormat();
      if (fmt) {
        setEditingFormat(fmt);
        setFormatEditorOpen(true);
      }
    } finally {
      setCreatingFormat(false);
    }
  };

  /**
   * Abre un formato existente en el editor.
   */
  const handleEditFormat = async (formatId: string) => {
    setOpeningSheet(formatId);
    try {
      const fmt = await onOpenFormat(formatId);
      if (fmt) {
        setEditingFormat(fmt);
        setFormatEditorOpen(true);
      }
    } finally {
      setOpeningSheet(null);
    }
  };

  /**
   * Abre un documento Excel en el editor.
   */
  const handleEditSheet = async (docId: string, docName: string) => {
    setOpeningSheet(docId);
    try {
      const result = await onOpenSheet(docId);
      if (result) {
        setExcelData(result.data);
        setExcelName(result.name || docName);
        setExcelDocId(docId);
        setExcelOpen(true);
      }
    } finally {
      setOpeningSheet(null);
    }
  };

  /**
   * Guarda los datos editados del Excel.
   */
  const handleSaveSheet = async (data: any[][], name: string) => {
    if (!excelDocId) return;
    await onSaveSheet(excelDocId, data, name);
    setExcelOpen(false);
  };

  return (
    <div className="space-y-5">
      {/* Ruta de navegación y botón regresar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-[#6B4A42]">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 font-medium text-[#D7068E] hover:text-[#3F2620]"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Panel principal</span>
          </button>
          <span className="text-[#F0E4D8]">/</span>
          <span className="flex items-center gap-1.5 font-medium text-[#3F2620]">
            <FolderOpen className="h-4 w-4" />
            {process.name}
          </span>
        </div>

        {/* Botón subir documentos + Nuevo formato */}
        <div className="flex items-center gap-2">
          {/* Botón "Nuevo formato" solo visible en pestaña Formatos */}
          {activeCategory === "formatos" && (
            <Button
              type="button"
              onClick={handleNewFormat}
              disabled={creatingFormat || uploading}
              variant="outline"
              className="border-[#D7068E]/30 text-[#D7068E] hover:bg-[#D7068E]/10"
            >
              {creatingFormat ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Plus className="mr-2 h-4 w-4" />
              )}
              Nuevo formato
            </Button>
          )}
          <Button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="bg-[#D7068E] text-white hover:bg-[#D7068E]/90"
          >
            {uploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Subiendo...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Subir archivos
              </>
            )}
          </Button>
        </div>

        {/* Input oculto para selección de archivos */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFileSelect}
          accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.webp"
          aria-label="Seleccionar archivos para subir"
        />
      </div>

      {/* Encabezado de la carpeta */}
      <section className="overflow-hidden rounded-xl border border-[#F0E4D8] bg-white shadow-sm">
        <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div className="flex items-start gap-4">
            <div
              className={cn(
                "flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl",
                process.soft
              )}
            >
              <Icon className={cn("h-7 w-7", process.accent)} />
            </div>
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-[#3F2620]">
                {process.name}
              </h2>
              <p className="max-w-xl text-sm text-[#6B4A42]">
                {process.description}
              </p>
              <p className="text-xs text-[#6B4A42]/70">
                {documents.length} archivo{documents.length !== 1 ? "s" : ""}{" "}
                almacenado{documents.length !== 1 ? "s" : ""} en esta carpeta ·{" "}
                {CATEGORIES.length} categorías disponibles
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pestañas de categorías (Todas + Modelos + Registros + Formatos + Documentos) */}
      <div className="overflow-x-auto rounded-xl border border-[#F0E4D8] bg-white p-2 shadow-sm">
        <div className="flex min-w-max items-center gap-1">
          {/* Pestaña "Todos" */}
          <CategoryTab
            label="Todos"
            icon={Layers}
            count={documents.length}
            active={activeCategory === ALL_TAB}
            onClick={() => setActiveCategory(ALL_TAB)}
            colorClasses="text-[#3F2620] bg-[#FFF4EA]"
          />
          {CATEGORIES.map((cat) => (
            <CategoryTab
              key={cat.id}
              label={cat.name}
              icon={cat.icon}
              count={countsByCategory[cat.id] || 0}
              active={activeCategory === cat.id}
              onClick={() => setActiveCategory(cat.id)}
              colorClasses={cn(cat.accent, cat.soft)}
            />
          ))}
        </div>
      </div>

      {/* Zona de subida por arrastre */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={handleDrop}
        className={cn(
          "rounded-xl border-2 border-dashed p-6 text-center transition-colors",
          dragActive
            ? "border-[#D7068E] bg-[#D7068E]/5"
            : "border-[#F0E4D8] bg-[#FFF4EA]"
        )}
      >
        <Upload className="mx-auto mb-2 h-8 w-8 text-[#D7068E]" />
        <p className="text-sm font-medium text-[#3F2620]">
          Arrastre los archivos aquí o haga clic en &quot;Subir archivos&quot;
        </p>
        <p className="mt-1 text-xs text-[#6B4A42]">
          Formatos permitidos: PDF, Word, Excel, PowerPoint e imágenes · Se
          clasificarán en una categoría al subir
        </p>
      </div>

      {/* Buscador interno de la carpeta */}
      <div className="flex items-center gap-3">
        <div className="relative max-w-md flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B4A42]/60" />
          <Input
            type="search"
            placeholder={`Buscar en ${process.name}${
              activeCategory !== ALL_TAB
                ? ` · ${getCategoryInfo(activeCategory).name}`
                : ""
            }...`}
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="border-[#F0E4D8] bg-white pl-9 text-[#3F2620] placeholder:text-[#6B4A42]/60 focus-visible:border-[#D7068E] focus-visible:ring-[#D7068E]/30"
            aria-label={`Buscar archivos en ${process.name}`}
          />
        </div>
        <span className="text-sm text-[#6B4A42]">
          {filtered.length} resultado{filtered.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Lista de documentos */}
      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-[#F0E4D8] bg-white py-12 text-center">
          <FileText className="mx-auto mb-3 h-10 w-10 text-[#6B4A42]/40" />
          <p className="text-sm font-medium text-[#3F2620]">
            {searchQuery.trim()
              ? "No se encontraron archivos con ese criterio."
              : activeCategory !== ALL_TAB
              ? `No hay archivos en la categoría "${getCategoryInfo(activeCategory).name}".`
              : "Esta carpeta aún no tiene archivos."}
          </p>
          <p className="mt-1 text-xs text-[#6B4A42]/70">
            {searchQuery.trim()
              ? "Intente con otro término de búsqueda."
              : "Suba su primer archivo para comenzar."}
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-[#F0E4D8] bg-white shadow-sm">
          {/* Encabezado de la tabla (oculto en móvil) */}
          <div className="hidden border-b border-[#F0E4D8] bg-[#FFF4EA] px-4 py-3 sm:grid sm:grid-cols-12 sm:gap-4">
            <div className="col-span-4 text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Nombre del archivo
            </div>
            <div className="col-span-2 text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Categoría
            </div>
            <div className="col-span-1 text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Tipo
            </div>
            <div className="col-span-2 text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Tamaño
            </div>
            <div className="col-span-2 text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Fecha de carga
            </div>
            <div className="col-span-1 text-right text-xs font-semibold uppercase tracking-wider text-[#6B4A42]">
              Acciones
            </div>
          </div>

          {/* Lista de documentos */}
          <ul className="divide-y divide-[#F0E4D8]">
            {filtered.map((doc) => {
              const cat = getCategoryInfo(doc.category);
              const CatIcon = cat.icon;
              return (
                <li
                  key={doc.id}
                  className="flex flex-col gap-2 px-4 py-3 transition-colors hover:bg-[#FFF4EA] sm:grid sm:grid-cols-12 sm:items-center sm:gap-4"
                >
                  {/* Nombre */}
                  <div className="col-span-4 flex items-center gap-3">
                    <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md bg-[#FFF4EA]">
                      <FileText className="h-5 w-5 text-[#6B4A42]" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-[#3F2620]">
                        {doc.name}
                      </p>
                      <p className="text-xs text-[#6B4A42]/70 sm:hidden">
                        {cat.name} · {getFileTypeLabel(doc.name)} ·{" "}
                        {formatUploadDate(doc.uploadedAt)}
                      </p>
                    </div>
                  </div>

                  {/* Categoría */}
                  <div className="col-span-2 flex items-center gap-1.5">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-xs font-semibold",
                        cat.badge
                      )}
                    >
                      <CatIcon className="h-3 w-3" />
                      {cat.name}
                    </span>
                  </div>

                  {/* Tipo */}
                  <div className="col-span-1 hidden sm:block">
                    <span
                      className={cn(
                        "inline-flex rounded-md border px-2 py-0.5 text-xs font-semibold",
                        getFileTypeColor(doc.name)
                      )}
                    >
                      {getFileTypeLabel(doc.name)}
                    </span>
                  </div>

                  {/* Tamaño */}
                  <div className="col-span-2 hidden text-sm text-[#6B4A42] sm:block">
                    {formatFileSize(doc.size)}
                  </div>

                  {/* Fecha */}
                  <div className="col-span-2 hidden text-sm text-[#6B4A42] sm:block">
                    {formatUploadDate(doc.uploadedAt)}
                  </div>

                  {/* Acciones */}
                  <div className="col-span-1 flex items-center justify-end gap-1">
                    {/* Botón editar formato (.dcafmt) */}
                    {doc.name.endsWith(".dcafmt") && (
                      <button
                        type="button"
                        onClick={() => handleEditFormat(doc.id)}
                        disabled={openingSheet === doc.id}
                        className="rounded-md p-1.5 text-[#D7068E] hover:bg-[#D7068E]/10 disabled:opacity-50"
                        aria-label={`Editar formato ${doc.name}`}
                        title="Editar formato"
                      >
                        {openingSheet === doc.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Edit3 className="h-4 w-4" />
                        )}
                      </button>
                    )}
                    {/* Botón editar Excel (.xlsx/.xls) */}
                    {doc.isEditableSheet && !doc.name.endsWith(".dcafmt") && (
                      <button
                        type="button"
                        onClick={() => handleEditSheet(doc.id, doc.name)}
                        disabled={openingSheet === doc.id}
                        className="rounded-md p-1.5 text-[#B58A1A] hover:bg-[#FFD24B]/20 disabled:opacity-50"
                        aria-label={`Editar Excel ${doc.name}`}
                        title="Editar Excel"
                      >
                        {openingSheet === doc.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <FileSpreadsheet className="h-4 w-4" />
                        )}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDownload(doc.id)}
                      disabled={downloadingId === doc.id}
                      className="rounded-md p-1.5 text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#D7068E] disabled:opacity-50"
                      aria-label={`Descargar ${doc.name}`}
                      title="Descargar"
                    >
                      {downloadingId === doc.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Download className="h-4 w-4" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDelete(doc)}
                      disabled={deletingId === doc.id}
                      className="rounded-md p-1.5 text-[#6B4A42] hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
                      aria-label={`Eliminar ${doc.name}`}
                      title="Eliminar"
                    >
                      {deletingId === doc.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* Diálogo de selección de categoría al subir archivos */}
      <Dialog open={pendingFiles !== null} onOpenChange={(open) => !open && setPendingFiles(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5 text-[#D7068E]" />
              Seleccione la categoría
            </DialogTitle>
            <DialogDescription>
              {pendingFiles && pendingFiles.length > 0 ? (
                <>
                  Va a subir{" "}
                  <span className="font-semibold text-[#3F2620]">
                    {pendingFiles.length} archivo
                    {pendingFiles.length !== 1 ? "s" : ""}
                  </span>{" "}
                  a la carpeta{" "}
                  <span className="font-semibold text-[#3F2620]">
                    {process.name}
                  </span>
                  . Elija la categoría de clasificación:
                </>
              ) : null}
            </DialogDescription>
          </DialogHeader>

          {/* Grid de categorías seleccionables */}
          <div className="grid grid-cols-2 gap-3 py-2">
            {CATEGORIES.map((cat) => {
              const CatIcon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    "flex flex-col items-start gap-1 rounded-lg border-2 p-3 text-left transition-all",
                    isSelected
                      ? "border-[#D7068E] bg-[#D7068E]/5 shadow-sm"
                      : "border-[#F0E4D8] bg-white hover:border-[#D7068E]/40"
                  )}
                  aria-pressed={isSelected}
                >
                  <div className="flex w-full items-center justify-between">
                    <div
                      className={cn(
                        "flex h-9 w-9 items-center justify-center rounded-md",
                        cat.soft
                      )}
                    >
                      <CatIcon className={cn("h-5 w-5", cat.accent)} />
                    </div>
                    {isSelected && (
                      <span className="rounded-full bg-[#D7068E] px-2 py-0.5 text-[10px] font-bold uppercase text-white">
                        Seleccionada
                      </span>
                    )}
                  </div>
                  <p className={cn("text-sm font-semibold", cat.accent)}>
                    {cat.name}
                  </p>
                  <p className="text-xs text-[#6B4A42]">{cat.description}</p>
                </button>
              );
            })}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setPendingFiles(null)}
            >
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={confirmUpload}
              disabled={uploading}
              className="bg-[#D7068E] text-white hover:bg-[#D7068E]/90"
            >
              {uploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Subiendo...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Subir {pendingFiles?.length ?? 0} archivo
                  {(pendingFiles?.length ?? 0) !== 1 ? "s" : ""}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cuadro de diálogo de confirmación de eliminación */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(open) => !open && setPendingDelete(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-600" />
              ¿Eliminar archivo?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Estás a punto de eliminar{" "}
              <span className="font-semibold text-[#3F2620]">
                &quot;{pendingDelete?.name}&quot;
              </span>{" "}
              de la categoría{" "}
              <span className="font-semibold text-[#3F2620]">
                {getCategoryInfo(pendingDelete?.category).name}
              </span>
              . Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Sí, eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Editor de formatos editables */}
      <FormatEditor
        open={formatEditorOpen}
        format={editingFormat}
        process={process}
        onSave={async (fmt) => {
          await onSaveFormat(fmt);
          setFormatEditorOpen(false);
        }}
        onClose={() => setFormatEditorOpen(false)}
      />

      {/* Editor de Excel */}
      <ExcelEditor
        open={excelOpen}
        initialData={excelData}
        fileName={excelName}
        onSave={handleSaveSheet}
        onClose={() => setExcelOpen(false)}
      />
    </div>
  );
}

/**
 * Pestaña individual de categoría con ícono y conteo.
 */
function CategoryTab({
  label,
  icon: Icon,
  count,
  active,
  onClick,
  colorClasses,
}: {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  count: number;
  active: boolean;
  onClick: () => void;
  colorClasses: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        active
          ? cn(colorClasses, "ring-2 ring-[#D7068E]/30")
          : "text-[#6B4A42] hover:bg-[#FFF4EA]"
      )}
      aria-pressed={active}
    >
      <Icon className="h-4 w-4 flex-shrink-0" />
      <span>{label}</span>
      <span
        className={cn(
          "rounded-full px-1.5 py-0.5 text-xs font-semibold",
          active ? "bg-white/70 text-[#3F2620]" : "bg-[#FFF4EA] text-[#6B4A42]"
        )}
      >
        {count}
      </span>
    </button>
  );
}
