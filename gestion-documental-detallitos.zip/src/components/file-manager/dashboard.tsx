"use client";

/**
 * Vista principal del panel de Detallitos con Amor · Gifting Studio.
 * Muestra la bienvenida al usuario, el nombre de la empresa, un resumen
 * con el total de documentos, las siete carpetas de áreas de gestión
 * y las cuatro categorías de clasificación.
 * Incluye el buscador general de documentos.
 */

import {
  FolderOpen,
  FileText,
  Search,
  Heart,
  TrendingUp,
  Inbox,
  Layers,
} from "lucide-react";
import {
  PROCESSES,
  CATEGORIES,
  getCategoryInfo,
  getFileTypeColor,
  getFileTypeLabel,
  formatUploadDate,
} from "@/lib/processes";
import type { DocumentMetadata } from "@/lib/document-store";
import { cn } from "@/lib/utils";

interface DashboardProps {
  /** Conteo de documentos por proceso */
  counts: Record<string, number>;
  /** Total general de documentos */
  total: number;
  /** Resultados de búsqueda global (cuando hay consulta) */
  searchQuery: string;
  searchResults: DocumentMetadata[];
  /** Callback al hacer clic en una carpeta */
  onOpenFolder: (processId: string) => void;
}

export function Dashboard({
  counts,
  total,
  searchQuery,
  searchResults,
  onOpenFolder,
}: DashboardProps) {
  const hasSearch = searchQuery.trim().length > 0;

  return (
    <div className="space-y-6">
      {/* Tarjeta de bienvenida con gradiente marrón/rosa */}
      <section className="overflow-hidden rounded-2xl border border-[#F0E4D8] bg-gradient-to-br from-[#3F2620] via-[#5A2E20] to-[#D7068E]/40 p-6 text-white shadow-md sm:p-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-[#FFD24B]">
              <Heart className="h-4 w-4 fill-current" />
              <span className="font-medium">Detallitos con Amor · Gifting Studio</span>
            </div>
            <h2 className="text-2xl font-bold sm:text-3xl">
              Cada detalle cuenta una historia de amor
            </h2>
            <p className="max-w-2xl text-sm text-white/80 sm:text-base">
              Organice, almacene y consulte los documentos de las áreas de
              gestión del estudio. Seleccione una carpeta para gestionar los
              archivos correspondientes.
            </p>
          </div>
          <div className="flex flex-col items-start gap-2 rounded-xl bg-white/10 p-4 backdrop-blur-sm sm:items-end">
            <div className="flex items-center gap-2 text-white/80">
              <Inbox className="h-5 w-5" />
              <span className="text-sm">Total de archivos</span>
            </div>
            <p className="text-3xl font-bold text-[#FFD24B]">{total}</p>
          </div>
        </div>
      </section>

      {/* Resumen rápido con estadísticas */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          icon={<Layers className="h-5 w-5" />}
          label="Procesos disponibles"
          value={String(PROCESSES.length)}
          accent="text-[#D7068E]"
          bg="bg-[#D7068E]/10"
        />
        <StatCard
          icon={<FolderOpen className="h-5 w-5" />}
          label="Carpetas activas"
          value={String(Object.keys(counts).filter((k) => counts[k] > 0).length)}
          accent="text-[#6B4A42]"
          bg="bg-[#6B4A42]/10"
        />
        <StatCard
          icon={<TrendingUp className="h-5 w-5" />}
          label="Promedio por carpeta"
          value={
            PROCESSES.length > 0
              ? (total / PROCESSES.length).toFixed(1)
              : "0"
          }
          accent="text-[#B58A1A]"
          bg="bg-[#FFD24B]/20"
        />
      </section>

      {/* Si hay búsqueda activa, mostrar resultados globales */}
      {hasSearch ? (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-[#D7068E]" />
              <h3 className="text-lg font-semibold text-[#3F2620]">
                Resultados de búsqueda
              </h3>
            </div>
            <span className="text-sm text-[#6B4A42]">
              {searchResults.length} archivo(s) encontrados
            </span>
          </div>
          {searchResults.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[#F0E4D8] bg-[#FFF4EA] py-12 text-center">
              <FileText className="mx-auto mb-3 h-10 w-10 text-[#6B4A42]/40" />
              <p className="text-sm text-[#6B4A42]">
                No se encontraron archivos que coincidan con &quot;
                {searchQuery}&quot;.
              </p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-xl border border-[#F0E4D8] bg-white">
              <ul className="divide-y divide-[#F0E4D8]">
                {searchResults.map((doc) => {
                  const process = PROCESSES.find((p) => p.id === doc.processId);
                  const cat = getCategoryInfo(doc.category);
                  const CatIcon = cat.icon;
                  return (
                    <li
                      key={doc.id}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-[#FFF4EA]"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-[#3F2620]">
                          {doc.name}
                        </p>
                        <p className="text-xs text-[#6B4A42]">
                          {process?.name} · {formatUploadDate(doc.uploadedAt)}
                        </p>
                      </div>
                      <span
                        className={cn(
                          "hidden items-center gap-1 rounded-md border px-2 py-0.5 text-xs font-semibold sm:inline-flex",
                          cat.badge
                        )}
                      >
                        <CatIcon className="h-3 w-3" />
                        {cat.name}
                      </span>
                      <span
                        className={cn(
                          "rounded-md border px-2 py-0.5 text-xs font-semibold",
                          getFileTypeColor(doc.name)
                        )}
                      >
                        {getFileTypeLabel(doc.name)}
                      </span>
                      <button
                        type="button"
                        onClick={() => onOpenFolder(doc.processId)}
                        className="rounded-md px-3 py-1 text-xs font-medium text-[#D7068E] hover:bg-[#D7068E]/10"
                      >
                        Abrir carpeta
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </section>
      ) : (
        <>
          {/* Título de la sección de carpetas */}
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <FolderOpen className="h-5 w-5 text-[#D7068E]" />
              <h3 className="text-lg font-semibold text-[#3F2620]">
                Carpetas de procesos
              </h3>
            </div>

            {/* Grid de carpetas */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {PROCESSES.map((p) => {
                const Icon = p.icon;
                const count = counts[p.id] || 0;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => onOpenFolder(p.id)}
                    className="group relative flex flex-col items-start gap-3 rounded-xl border border-[#F0E4D8] bg-white p-5 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-[#D7068E] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#D7068E]/30"
                    aria-label={`Abrir carpeta ${p.name}`}
                  >
                    {/* Encabezado con ícono y conteo */}
                    <div className="flex w-full items-center justify-between">
                      <div
                        className={cn(
                          "flex h-12 w-12 items-center justify-center rounded-lg transition-colors",
                          p.soft
                        )}
                      >
                        <Icon className={cn("h-6 w-6", p.accent)} />
                      </div>
                      <span className="rounded-full bg-[#FFF4EA] px-2.5 py-1 text-xs font-semibold text-[#6B4A42] group-hover:bg-[#D7068E] group-hover:text-white">
                        {count} doc{count !== 1 ? "s." : "."}
                      </span>
                    </div>

                    {/* Nombre y descripción */}
                    <div className="space-y-1">
                      <h4 className="text-base font-semibold text-[#3F2620]">
                        {p.name}
                      </h4>
                      <p className="line-clamp-2 text-xs text-[#6B4A42]">
                        {p.description}
                      </p>
                    </div>

                    {/* Indicador de apertura */}
                    <div className="mt-auto flex items-center gap-1 pt-2 text-xs font-medium text-[#D7068E] opacity-0 transition-opacity group-hover:opacity-100">
                      <FolderOpen className="h-3.5 w-3.5" />
                      <span>Abrir carpeta</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Sección informativa de categorías de clasificación */}
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <Layers className="h-5 w-5 text-[#D7068E]" />
              <h3 className="text-lg font-semibold text-[#3F2620]">
                Categorías de clasificación
              </h3>
            </div>
            <p className="text-sm text-[#6B4A42]">
              Dentro de cada carpeta de proceso, los archivos se organizan en
              cuatro categorías. Al subir un archivo deberá seleccionar a cuál
              pertenece:
            </p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {CATEGORIES.map((cat) => {
                const CatIcon = cat.icon;
                return (
                  <div
                    key={cat.id}
                    className="rounded-xl border border-[#F0E4D8] bg-white p-4 shadow-sm"
                  >
                    <div
                      className={cn(
                        "mb-3 flex h-10 w-10 items-center justify-center rounded-lg",
                        cat.soft
                      )}
                    >
                      <CatIcon className={cn("h-5 w-5", cat.accent)} />
                    </div>
                    <h4 className={cn("text-sm font-semibold", cat.accent)}>
                      {cat.name}
                    </h4>
                    <p className="mt-1 text-xs text-[#6B4A42]">
                      {cat.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

/**
 * Tarjeta pequeña de estadística usada en el resumen.
 */
function StatCard({
  icon,
  label,
  value,
  accent,
  bg,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: string;
  bg: string;
}) {
  return (
    <div className="flex items-center gap-4 rounded-xl border border-[#F0E4D8] bg-white p-4 shadow-sm">
      <div className={cn("flex h-11 w-11 items-center justify-center rounded-lg", bg, accent)}>
        {icon}
      </div>
      <div className="leading-tight">
        <p className="text-xs text-[#6B4A42]">{label}</p>
        <p className={cn("text-xl font-bold", accent)}>{value}</p>
      </div>
    </div>
  );
}
