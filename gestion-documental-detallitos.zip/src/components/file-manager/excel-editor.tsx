"use client";

/**
 * Editor de Excel en el navegador.
 *
 * Permite:
 * - Cargar un archivo Excel (.xlsx/.xls) existente.
 * - Editar las celdas directamente en una tabla editable.
 * - Agregar y quitar filas/columnas.
 * - Guardar los cambios de vuelta al almacenamiento.
 * - Descargar como .xlsx usando la librería SheetJS (xlsx).
 */

import { useEffect, useRef, useState } from "react";
import {
  Save,
  Download,
  Plus,
  Trash2,
  Table as TableIcon,
  Loader2,
  FileSpreadsheet,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import * as XLSX from "xlsx";
import { cn } from "@/lib/utils";

interface ExcelEditorProps {
  open: boolean;
  /** Datos iniciales (matriz de celdas) */
  initialData: any[][];
  /** Nombre del archivo */
  fileName: string;
  /** Callback al guardar */
  onSave: (data: any[][], fileName: string) => Promise<void>;
  /** Callback al cerrar */
  onClose: () => void;
}

export function ExcelEditor({
  open,
  initialData,
  fileName,
  onSave,
  onClose,
}: ExcelEditorProps) {
  const [data, setData] = useState<any[][]>([]);
  const [name, setName] = useState(fileName);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [activeCell, setActiveCell] = useState<{ r: number; c: number } | null>(
    null
  );

  useEffect(() => {
    // Normalizar: asegurar al menos 1 fila y 1 columna
    const normalized = normalizeData(initialData);
    setData(normalized);
    setName(fileName);
  }, [initialData, fileName, open]);

  const cols = data[0]?.length ?? 0;
  const rows = data.length;

  const updateCell = (r: number, c: number, value: string) => {
    setData((prev) => {
      const copy = prev.map((row) => [...row]);
      if (!copy[r]) copy[r] = [];
      copy[r][c] = value;
      return copy;
    });
  };

  const addRow = () => {
    setData((prev) => [...prev, Array(cols).fill("")]);
  };

  const addCol = () => {
    setData((prev) => prev.map((row) => [...row, ""]));
  };

  const removeRow = (r: number) => {
    if (rows <= 1) return;
    setData((prev) => prev.filter((_, idx) => idx !== r));
  };

  const removeCol = (c: number) => {
    if (cols <= 1) return;
    setData((prev) => prev.map((row) => row.filter((_, idx) => idx !== c)));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(data, name);
    } finally {
      setSaving(false);
    }
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const ws = XLSX.utils.aoa_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Hoja 1");
      const finalName = name.endsWith(".xlsx")
        ? name
        : `${name.replace(/\.[^.]+$/, "")}.xlsx`;
      XLSX.writeFile(wb, finalName);
    } finally {
      setExporting(false);
    }
  };

  // Navegación con teclado entre celdas
  const handleKeyDown = (
    e: React.KeyboardEvent,
    r: number,
    c: number
  ) => {
    if (e.key === "ArrowDown" || (e.key === "Enter" && !e.shiftKey)) {
      e.preventDefault();
      const next = document.querySelector(
        `td[data-cell="${r + 1}-${c}"] input`
      ) as HTMLInputElement | null;
      next?.focus();
      setActiveCell({ r: r + 1, c });
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const next = document.querySelector(
        `td[data-cell="${r - 1}-${c}"] input`
      ) as HTMLInputElement | null;
      next?.focus();
      setActiveCell({ r: r - 1, c });
    } else if (e.key === "ArrowRight" || e.key === "Tab") {
      e.preventDefault();
      const next = document.querySelector(
        `td[data-cell="${r}-${c + 1}"] input`
      ) as HTMLInputElement | null;
      next?.focus();
      setActiveCell({ r, c: c + 1 });
    } else if (e.key === "ArrowLeft" || (e.key === "Tab" && e.shiftKey)) {
      e.preventDefault();
      const next = document.querySelector(
        `td[data-cell="${r}-${c - 1}"] input`
      ) as HTMLInputElement | null;
      next?.focus();
      setActiveCell({ r, c: c - 1 });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] w-[95vw] max-w-6xl overflow-hidden p-0">
        {/* Barra superior */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F0E4D8] bg-[#FFF4EA] px-4 py-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-[#B58A1A]" />
            <div>
              <p className="text-sm font-bold text-[#3F2620]">
                Editor de Excel
              </p>
              <p className="text-xs text-[#6B4A42]">
                {rows} filas × {cols} columnas
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="rounded-md border border-[#F0E4D8] bg-white px-2 py-1 text-xs text-[#3F2620]"
              aria-label="Nombre del archivo"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleExport}
              disabled={exporting}
              className="border-[#B58A1A]/40 text-[#B58A1A]"
            >
              {exporting ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-1.5 h-4 w-4" />
              )}
              Descargar .xlsx
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={handleSave}
              disabled={saving}
              className="bg-[#D7068E] text-white hover:bg-[#D7068E]/90"
            >
              {saving ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-1.5 h-4 w-4" />
              )}
              Guardar
            </Button>
          </div>
        </div>

        {/* Toolbar de filas/columnas */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#F0E4D8] bg-white px-4 py-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addRow}
            className="border-[#F0E4D8] text-[#6B4A42]"
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            Fila
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addCol}
            className="border-[#F0E4D8] text-[#6B4A42]"
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            Columna
          </Button>
          <div className="ml-auto text-xs text-[#6B4A42]">
            Usa las flechas o Tab para navegar entre celdas
          </div>
        </div>

        {/* Tabla editable */}
        <div className="max-h-[70vh] overflow-auto bg-white">
          <table className="border-collapse">
            <thead className="sticky top-0 z-10">
              <tr className="bg-[#FFF4EA]">
                <th className="sticky left-0 z-20 w-10 border border-[#F0E4D8] bg-[#FFF4EA] p-1 text-center text-xs font-bold text-[#6B4A42]">
                  #
                </th>
                {Array.from({ length: cols }).map((_, c) => (
                  <th
                    key={c}
                    className="group relative min-w-[120px] border border-[#F0E4D8] bg-[#FFF4EA] p-1 text-center text-xs font-bold text-[#6B4A42]"
                  >
                    {columnLabel(c)}
                    {cols > 1 && (
                      <button
                        type="button"
                        onClick={() => removeCol(c)}
                        className="absolute right-0 top-0 hidden rounded-bl bg-red-50 p-0.5 text-red-600 group-hover:block"
                        aria-label={`Eliminar columna ${columnLabel(c)}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, r) => (
                <tr key={r}>
                  <td className="sticky left-0 z-10 group relative w-10 border border-[#F0E4D8] bg-[#FFF4EA] p-1 text-center text-xs font-medium text-[#6B4A42]">
                    {r + 1}
                    {rows > 1 && (
                      <button
                        type="button"
                        onClick={() => removeRow(r)}
                        className="absolute right-0 top-0 hidden rounded-bl bg-red-50 p-0.5 text-red-600 group-hover:block"
                        aria-label={`Eliminar fila ${r + 1}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </td>
                  {Array.from({ length: cols }).map((_, c) => (
                    <td
                      key={c}
                      data-cell={`${r}-${c}`}
                      className={cn(
                        "border border-[#F0E4D8] p-0",
                        activeCell?.r === r && activeCell?.c === c
                          ? "ring-2 ring-[#D7068E]/40 ring-inset"
                          : ""
                      )}
                    >
                      <input
                        value={row[c] ?? ""}
                        onChange={(e) => updateCell(r, c, e.target.value)}
                        onFocus={() => setActiveCell({ r, c })}
                        onKeyDown={(e) => handleKeyDown(e, r, c)}
                        className="w-full bg-transparent px-2 py-1 text-sm text-[#3F2620] outline-none focus:bg-[#FFD24B]/15"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pie informativo */}
        <div className="border-t border-[#F0E4D8] bg-[#FFF4EA] px-4 py-2 text-center text-xs text-[#6B4A42]">
          Los cambios se guardan en el navegador y se pueden exportar a Excel (.xlsx)
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Normaliza una matriz de datos para que sea rectangular.
 */
function normalizeData(data: any[][]): any[][] {
  if (!data || data.length === 0) {
    return [["", ""], ["", ""]];
  }
  const maxCols = Math.max(...data.map((r) => r?.length ?? 0), 1);
  return data.map((row) => {
    const r = row ?? [];
    const padded = [...r];
    while (padded.length < maxCols) padded.push("");
    return padded;
  });
}

/**
 * Convierte un índice de columna a etiqueta tipo Excel (A, B, ..., Z, AA, AB...).
 */
function columnLabel(idx: number): string {
  let label = "";
  let n = idx;
  while (n >= 0) {
    label = String.fromCharCode(65 + (n % 26)) + label;
    n = Math.floor(n / 26) - 1;
  }
  return label;
}
