"use client";

/**
 * Barra lateral de navegación de Detallitos con Amor · Gifting Studio.
 * Muestra el logo, el nombre de la empresa y la lista de áreas de gestión
 * documental con el conteo de archivos en cada una.
 */

import { FolderKanban, Home, X } from "lucide-react";
import Image from "next/image";
import { PROCESSES } from "@/lib/processes";
import { cn } from "@/lib/utils";

interface SidebarProps {
  /** Proceso activo actualmente (o null para la vista principal) */
  activeProcessId: string | null;
  /** Conteo de documentos por proceso */
  counts: Record<string, number>;
  /** Total general de documentos */
  total: number;
  /** Callback al seleccionar un proceso (null = vista principal) */
  onSelect: (processId: string | null) => void;
  /** Indica si la barra lateral está abierta en móvil */
  mobileOpen: boolean;
  /** Callback para cerrar la barra lateral en móvil */
  onCloseMobile: () => void;
}

export function Sidebar({
  activeProcessId,
  counts,
  total,
  onSelect,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  return (
    <>
      {/* Overlay oscuro para móvil cuando el sidebar está abierto */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          // Estilos base: fondo crema oscuro con texto marrón
          "fixed inset-y-0 left-0 z-40 flex w-72 flex-col bg-[#FFF4EA] text-[#3F2620] transition-transform duration-300 lg:static lg:translate-x-0",
          // Borde derecho decorativo color magenta
          "border-r border-[#F0E4D8]",
          // Posición en móvil
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
        aria-label="Navegación de procesos"
      >
        {/* Encabezado del sidebar con logo y nombre de la empresa */}
        <div className="flex items-center justify-between gap-3 border-b border-[#F0E4D8] px-5 py-5">
          <div className="flex items-center gap-3">
            {/* Logo de Detallitos con Amor */}
            <div className="relative h-12 w-12 overflow-hidden rounded-full ring-2 ring-[#D7068E]/30">
              <Image
                src="/logo-dca.jpeg"
                alt="Detallitos con Amor"
                fill
                sizes="48px"
                className="object-cover"
                priority
              />
            </div>
            <div className="leading-tight">
              <p className="text-sm font-bold tracking-wide text-[#3F2620]">
                Detallitos con Amor
              </p>
              <p className="text-xs font-medium text-[#D7068E]">
                Gifting Studio
              </p>
            </div>
          </div>
          {/* Botón cerrar (solo móvil) */}
          <button
            type="button"
            onClick={onCloseMobile}
            className="rounded-md p-1.5 text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#D7068E] lg:hidden"
            aria-label="Cerrar menú"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Botón vista principal */}
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <button
            type="button"
            onClick={() => onSelect(null)}
            className={cn(
              "mb-2 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors",
              activeProcessId === null
                ? "bg-[#D7068E] text-white shadow-sm"
                : "text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#3F2620]"
            )}
          >
            <Home className="h-5 w-5 flex-shrink-0" />
            <span className="flex-1 font-medium">Panel principal</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-xs font-semibold",
                activeProcessId === null
                  ? "bg-white/25 text-white"
                  : "bg-[#D7068E]/15 text-[#D7068E]"
              )}
            >
              {total}
            </span>
          </button>

          <p className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-wider text-[#6B4A42]/70">
            Procesos de Talento Humano
          </p>

          {/* Lista de áreas (carpetas) */}
          <ul className="space-y-1">
            {PROCESSES.map((p) => {
              const Icon = p.icon;
              const isActive = activeProcessId === p.id;
              const count = counts[p.id] || 0;
              return (
                <li key={p.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(p.id)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors",
                      isActive
                        ? "bg-[#D7068E] text-white shadow-sm"
                        : "text-[#6B4A42] hover:bg-[#D7068E]/10 hover:text-[#3F2620]"
                    )}
                  >
                    <Icon className="h-5 w-5 flex-shrink-0" />
                    <span className="flex-1 font-medium leading-tight">
                      {p.name}
                    </span>
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-xs font-semibold",
                        isActive
                          ? "bg-white/25 text-white"
                          : "bg-[#3F2620]/8 text-[#6B4A42]"
                      )}
                    >
                      {count}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Pie del sidebar */}
        <div className="border-t border-[#F0E4D8] px-5 py-4 text-xs text-[#6B4A42]">
          <p className="font-medium">Cada detalle cuenta</p>
          <p className="font-semibold text-[#D7068E]">una historia de amor</p>
        </div>
      </aside>
    </>
  );
}
