import type { NextConfig } from "next";

// Configuración de Next.js para Detallitos con Amor · Gifting Studio
//
// - En el sandbox (dev preview): se usa "standalone" para que el preview
//   funcione correctamente.
// - En Netlify (build): se usa "export" para generar archivos estáticos
//   que se pueden publicar sin servidor ni funciones serverless.
//   Netlify establece automáticamente la variable NETLIFY=true durante el build.
const nextConfig: NextConfig = {
  output: process.env.NETLIFY ? "export" : "standalone",
  // Generar carpetas con trailing slash para mejor compatibilidad con
  // hosting estático cuando se construye para Netlify.
  trailingSlash: process.env.NETLIFY ? true : undefined,
  images: {
    unoptimized: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
