# Detallitos con Amor · Gifting Studio
## Plataforma de Gestión Documental de Talento Humano

Sistema web profesional para organizar, almacenar, consultar y **editar** documentos de los procesos del área de Talento Humano, con identidad visual de Detallitos con Amor · Gifting Studio.

> "Cada detalle cuenta una historia de amor"

---

## Características principales

### Gestión documental
- **7 carpetas de procesos**: Reclutamiento, Selección, Vinculación, Inducción, Capacitación, Evaluación del desempeño y Bienestar laboral.
- **4 categorías de clasificación** dentro de cada carpeta:
  - **Modelos** — documentos de referencia o ejemplos ya diligenciados.
  - **Registros** — evidencias de ejecución (actas, constancias, listados).
  - **Formatos** — plantillas y formularios editables.
  - **Documentos** — manuales, políticas y material informativo.
- Subida manual de archivos (PDF, Word, Excel, PowerPoint e imágenes).
- Descarga y eliminación de documentos con confirmación.
- Búsqueda por nombre dentro de cada carpeta y búsqueda global.
- Almacenamiento persistente con IndexedDB (los archivos permanecen tras cerrar el navegador).

### Editor de formatos editables
- Crear formatos desde cero con **caja de calidad siguiendo normas APA**.
- **Numeración consecutiva automática** por proceso: `DCA-TH-REC-001`, `DCA-TH-SEL-001`, etc.
- Campos editables: título, tipo de documento, versión, autor.
- Secciones editables con encabezado y cuerpo (agregar/quitar).
- Vista previa del documento antes de exportar.
- **Exportación a PDF** con normas APA (márgenes 2.54 cm, Times New Roman 12, interlineado doble, numeración de páginas).
- **Exportación a Word (.docx)** con tabla de caja de calidad, encabezado y pie de página.

### Editor de Excel
- Abrir cualquier archivo .xlsx/.xls directamente en el editor.
- Tabla editable tipo hoja de cálculo con encabezados de columna (A, B, C...).
- Navegación con flechas y Tab entre celdas.
- Agregar/quitar filas y columnas.
- Guardar cambios en el navegador para re-editar después.
- Descargar como .xlsx.

### Diseño
- Identidad visual de Detallitos con Amor:
  - Paleta: crema `#FFFBF7`, marrón `#3F2620`, rosa magenta `#D7068E`, dorado `#FFD24B`.
  - Tipografía Poppins.
  - Logo embebido.
- Panel lateral de navegación con conteo por carpeta.
- Encabezado con buscador global.
- Diseño responsive (computador, tableta, celular).
- Footer con datos de contacto reales.

---

## Estructura del proyecto

```
.
├── public/
│   ├── logo-dca.jpeg          # Logo de Detallitos con Amor
│   ├── logo.svg               # Logo vectorial
│   └── robots.txt
├── src/
│   ├── app/
│   │   ├── layout.tsx         # Layout raíz con Poppins y metadatos
│   │   ├── page.tsx           # Página principal (panel + carpetas)
│   │   └── globals.css        # Paleta de colores y estilos
│   ├── components/
│   │   ├── file-manager/
│   │   │   ├── sidebar.tsx        # Barra lateral de navegación
│   │   │   ├── header.tsx         # Encabezado con buscador
│   │   │   ├── dashboard.tsx      # Panel principal con carpetas
│   │   │   ├── folder-view.tsx    # Vista de carpeta con documentos
│   │   │   ├── format-editor.tsx  # Editor de formatos con caja APA
│   │   │   └── excel-editor.tsx   # Editor de Excel en el navegador
│   │   └── ui/                # Componentes shadcn/ui
│   ├── lib/
│   │   ├── processes.ts       # Configuración de procesos y categorías
│   │   ├── document-store.ts  # Almacenamiento IndexedDB de documentos
│   │   ├── format-store.ts    # Almacenamiento de formatos editables
│   │   └── format-export.ts   # Exportación a PDF y Word
│   └── hooks/
│       ├── use-toast.ts
│       └── use-mobile.ts
├── netlify.toml               # Configuración de despliegue en Netlify
├── next.config.ts             # Configuración de Next.js
├── package.json
└── README.md
```

---

## Requisitos

- Node.js 20+ o Bun
- Navegador moderno con soporte para IndexedDB

---

## Instalación

### Con Bun (recomendado)

```bash
# Clonar el repositorio
git clone https://github.com/TU_USUARIO/gestion-documental-detallitos.git
cd gestion-documental-detallitos

# Instalar dependencias
bun install

# Iniciar en modo desarrollo
bun run dev
```

### Con npm

```bash
git clone https://github.com/TU_USUARIO/gestion-documental-detallitos.git
cd gestion-documental-detallitos

npm install --legacy-peer-deps

npm run dev
```

Abrir http://localhost:3000 en el navegador.

---

## Scripts disponibles

| Comando | Descripción |
|---|---|
| `bun run dev` | Inicia el servidor de desarrollo |
| `bun run build` | Construye la aplicación para producción |
| `bun run start` | Inicia el servidor de producción |
| `bun run lint` | Ejecuta ESLint |

---

## Despliegue en Netlify

### Opción 1: Desde Git (recomendado)

1. Sube este repositorio a GitHub.
2. Inicia sesión en [Netlify](https://app.netlify.com/).
3. **Add new site → Import an existing project**.
4. Conecta tu cuenta de GitHub y selecciona el repositorio.
5. La configuración se detecta automáticamente desde `netlify.toml`:
   - **Build command**: `bun run build`
   - **Publish directory**: `.next`
6. **Deploy**.

### Opción 2: Netlify CLI

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Iniciar sesión
netlify login

# Desplegar
netlify deploy --prod --build
```

---

## Uso de la plataforma

### Panel principal
1. Muestra bienvenida, estadísticas y las 7 carpetas de procesos.
2. Usa el buscador del encabezado para encontrar documentos globalmente.

### Gestionar documentos
1. Haz clic en una carpeta para ver su contenido.
2. Filtra por categoría con las pestañas (Todos, Modelos, Registros, Formatos, Documentos).
3. Sube archivos con el botón "Subir archivos" o arrastrándolos a la zona punteada.
4. Al subir, selecciona la categoría correspondiente.

### Crear y editar formatos
1. Entra a una carpeta y selecciona la pestaña **Formatos**.
2. Haz clic en **Nuevo formato**.
3. Se genera automáticamente el código consecutivo (ej: `DCA-TH-REC-001`).
4. Completa la caja de calidad: título, tipo, versión, autor.
5. Edita las secciones (encabezado y cuerpo), agrega o quita según necesites.
6. Usa **Vista previa** para ver cómo quedará.
7. **Guarda** para conservar cambios y poder re-editar después.
8. Exporta a **PDF** o **Word** con las normas APA aplicadas.

### Editar Excel
1. Sube un archivo .xlsx a cualquier carpeta.
2. En la lista de archivos, haz clic en el ícono de hoja de cálculo (Editar Excel).
3. Edita las celdas directamente, agrega filas/columnas.
4. **Guarda** para conservar cambios o **Descarga .xlsx** para exportar.

---

## Tecnologías utilizadas

- **Next.js 16** con App Router y TypeScript
- **Tailwind CSS 4** para los estilos
- **shadcn/ui** para los componentes de interfaz
- **Lucide Icons** para la iconografía
- **IndexedDB** para el almacenamiento persistente
- **jsPDF** para exportación a PDF
- **docx** para exportación a Word
- **SheetJS (xlsx)** para edición de Excel
- **Poppins** (Google Fonts) como tipografía

---

## Datos de la empresa

- **Detallitos con Amor · Gifting Studio**
- Email: detallitosconamorth@gmail.com
- Teléfono: +57 305 255 4170
- Horario: Lun a sáb, 8:00 a.m. – 6:00 p.m.
- Ubicación: Colombia

---

© Detallitos con Amor · Gifting Studio — Hecho con dedicación en Colombia
