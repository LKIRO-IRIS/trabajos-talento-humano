# HUMAN TALENT S.A.S.
## Plataforma Digital de Gestión Documental de Talento Humano

Sistema web profesional para organizar, almacenar y consultar los documentos correspondientes a los procesos del área de Talento Humano.

---

## Características principales

- **Apariencia empresarial**: interfaz moderna con colores institucionales (azul oscuro, azul claro, blanco y gris), panel lateral de navegación y apariencia similar a un explorador de archivos empresarial.
- **Siete carpetas de procesos**:
  1. Reclutamiento
  2. Selección
  3. Vinculación
  4. Inducción
  5. Capacitación
  6. Evaluación del desempeño
  7. Bienestar laboral
- **Gestión completa de documentos** dentro de cada carpeta:
  - Subir documentos manualmente (PDF, Word, Excel, PowerPoint e imágenes).
  - Visualizar nombre, tipo, tamaño y fecha de carga.
  - Descargar documentos.
  - Eliminar documentos con confirmación.
  - Buscar documentos por nombre.
- **Panel principal** con bienvenida, conteo de documentos por carpeta y total general.
- **Buscador general** de documentos en todos los procesos.
- **Diseño adaptable** a computadores, tabletas y celulares.
- **Almacenamiento persistente** mediante IndexedDB: los documentos permanecen disponibles después de cerrar y volver a abrir la página.

---

## Estructura del proyecto

```
src/
├── app/
│   ├── layout.tsx              # Layout raíz con metadatos
│   ├── page.tsx                # Página principal (panel + carpetas)
│   └── globals.css             # Estilos globales
├── components/
│   └── file-manager/
│       ├── sidebar.tsx         # Barra lateral de navegación
│       ├── header.tsx          # Encabezado con buscador
│       ├── dashboard.tsx       # Panel principal con carpetas
│       └── folder-view.tsx     # Vista de carpeta con documentos
└── lib/
    ├── processes.ts            # Configuración de procesos y tipos
    └── document-store.ts       # Almacenamiento IndexedDB
```

---

## Tecnologías utilizadas

- **HTML, CSS y JavaScript** (vía Next.js 16 con TypeScript)
- **Tailwind CSS 4** para los estilos
- **shadcn/ui** para los componentes de interfaz
- **IndexedDB** para el almacenamiento persistente y seguro de documentos
- **Lucide Icons** para la iconografía

---

## Publicación en Netlify

### Opción 1: Despliegue continuo (recomendado)

1. Sube este proyecto a un repositorio de GitHub.
2. Inicia sesión en [Netlify](https://app.netlify.com/).
3. Haz clic en **Add new site → Import an existing project**.
4. Conecta tu cuenta de GitHub y selecciona el repositorio.
5. Configuración detectada automáticamente desde `netlify.toml`:
   - **Build command**: `bun run build`
   - **Publish directory**: `.next`
6. Haz clic en **Deploy**.

### Opción 2: Despliegue manual (arrastrar y soltar)

1. Ejecuta `bun run build` localmente.
2. Inicia sesión en Netlify.
3. Arrastra la carpeta `.next` (o el proyecto completo) a la zona de despliegue de Netlify.

### Opción 3: Netlify CLI

```bash
npm install -g netlify-cli
netlify login
netlify deploy --build
# Para despliegue de producción:
netlify deploy --prod --build
```

---

## Uso de la plataforma

1. **Acceder al panel principal**: muestra la bienvenida, las estadísticas generales y las siete carpetas de procesos.
2. **Buscar documentos globalmente**: usa el campo de búsqueda del encabezado para encontrar documentos en cualquier carpeta por su nombre.
3. **Abrir una carpeta**: haz clic en cualquiera de las siete carpetas para ver su contenido.
4. **Subir documentos**:
   - Haz clic en el botón **Subir documentos** y selecciona uno o varios archivos, o
   - Arrastra los archivos directamente a la zona punteada.
   - Formatos permitidos: PDF, Word (.doc/.docx), Excel (.xls/.xlsx), PowerPoint (.ppt/.pptx) e imágenes (.jpg/.jpeg/.png/.gif/.webp).
5. **Buscar dentro de una carpeta**: usa el campo de búsqueda interno de la carpeta.
6. **Descargar un documento**: haz clic en el ícono de descarga del documento.
7. **Eliminar un documento**: haz clic en el ícono de eliminar y confirma la acción.
8. **Regresar al panel principal**: usa el botón **Panel principal** del encabezado de ruta o en la barra lateral.

---

## Notas técnicas

- Los documentos se almacenan localmente en el navegador mediante **IndexedDB**, por lo que están disponibles después de cerrar y volver a abrir la página.
- Cada documento queda asociado exclusivamente a la carpeta del proceso seleccionado al momento de la subida.
- No se incluyen documentos ficticios: el usuario carga sus propios archivos.

---

© HUMAN TALENT S.A.S. — Plataforma de Gestión Documental de Talento Humano
