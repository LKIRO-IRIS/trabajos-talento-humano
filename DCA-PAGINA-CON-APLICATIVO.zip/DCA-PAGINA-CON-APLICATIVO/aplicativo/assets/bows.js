/* =========================================================
   DCA · Sistema de globos SVG 3D realista (efecto 3D con gradientes)
   100% compatible con todos los navegadores, sin librerías
   ========================================================= */

(function(window) {
  'use strict';

  // Contador para IDs únicos de gradientes
  var balloonIdCounter = 0;

  // Paletas de colores 3D por variante (light, mid, dark)
  var COLOR_PALETTES = {
    'magenta':        { light: '#ff5fb0', mid: '#d7068e', dark: '#7a044c', knot: '#a6056c', thread: '#a6056c' },
    'gold':           { light: '#fff0a0', mid: '#ffd24b', dark: '#9c7a1e', knot: '#c9a02e', thread: '#c9a02e' },
    'rose':           { light: '#ffd6e8', mid: '#ff9ec7', dark: '#c46b9a', knot: '#d7068e', thread: '#d7068e' },
    'cream':          { light: '#ffffff', mid: '#fff4ea', dark: '#d4bfa8', knot: '#d7068e', thread: '#d7068e' },
    'magenta-gold':   { light: '#ff5fb0', mid: '#d7068e', dark: '#7a044c', knot: '#c9a02e', thread: '#c9a02e' },
    'gold-magenta':   { light: '#fff0a0', mid: '#ffd24b', dark: '#9c7a1e', knot: '#d7068e', thread: '#d7068e' },
    'rose-gold':      { light: '#ffd6e8', mid: '#ff9ec7', dark: '#c46b9a', knot: '#c9a02e', thread: '#c9a02e' }
  };

  /**
   * Genera el SVG de un globo 3D realista
   * @param {string} colorClass - clase de color: 'magenta', 'gold', 'rose', etc.
   * @param {string} sizeClass - clase de tamaño: 'sm', 'md', 'lg', 'xl'
   * @param {boolean} floatAnim - si tiene animación de flotación
   * @returns {string} HTML del globo
   */
  function createBalloon(colorClass, sizeClass, floatAnim) {
    colorClass = colorClass || 'magenta';
    sizeClass = sizeClass || 'md';
    var classes = ['dca-balloon', 'dca-balloon--' + colorClass, 'dca-balloon--' + sizeClass];
    if (floatAnim) classes.push('dca-balloon--float');

    var palette = COLOR_PALETTES[colorClass] || COLOR_PALETTES['magenta'];
    var uid = 'balloon-grad-' + (++balloonIdCounter);

    // SVG con gradiente radial 3D, reflejo especular, borde oscuro
    return '<span class="' + classes.join(' ') + '" aria-hidden="true">' +
      '<svg viewBox="0 0 40 56" xmlns="http://www.w3.org/2000/svg">' +
        '<defs>' +
          // Gradiente radial principal del cuerpo (luz desde arriba-izquierda)
          '<radialGradient id="' + uid + '" cx="35%" cy="30%" r="70%">' +
            '<stop offset="0%" stop-color="' + palette.light + '" />' +
            '<stop offset="40%" stop-color="' + palette.mid + '" />' +
            '<stop offset="100%" stop-color="' + palette.dark + '" />' +
          '</radialGradient>' +
          // Filtro de sombra
          '<filter id="' + uid + '-shadow" x="-30%" y="-30%" width="160%" height="160%">' +
            '<feDropShadow dx="0" dy="2" stdDeviation="1.5" flood-color="rgba(0,0,0,0.3)" />' +
          '</filter>' +
          // Filtro de blur para el reflejo
          '<filter id="' + uid + '-blur">' +
            '<feGaussianBlur stdDeviation="0.8" />' +
          '</filter>' +
        '</defs>' +
        // Hilo del globo (ondulado)
        '<path d="M20,46 Q17,49 20,52 Q23,55 20,56" stroke="' + palette.thread + '" stroke-width="0.7" fill="none" opacity="0.6" stroke-linecap="round" />' +
        // Cuerpo del globo con gradiente 3D y sombra
        '<path d="M20,1 C9,1 2,9 2,20 C2,28 6,34 11,38 L13,41 L15,43 L17,44 L20,45 L23,44 L25,43 L27,41 L29,38 C34,34 38,28 38,20 C38,9 31,1 20,1 Z" ' +
          'fill="url(#' + uid + ')" ' +
          'stroke="' + palette.dark + '" ' +
          'stroke-width="0.5" ' +
          'filter="url(#' + uid + '-shadow)" />' +
        // Reflejo especular grande (difuso, arriba-izquierda)
        '<ellipse cx="13" cy="13" rx="5" ry="7" fill="rgba(255,255,255,0.45)" transform="rotate(-25 13 13)" filter="url(#' + uid + '-blur)" />' +
        // Reflejo especular pequeño (brillante, centro del reflejo)
        '<ellipse cx="12" cy="11" rx="2.5" ry="3.5" fill="rgba(255,255,255,0.8)" transform="rotate(-25 12 11)" />' +
        // Reflejo secundario abajo-derecha (luz de rebote)
        '<ellipse cx="28" cy="30" rx="3" ry="4" fill="rgba(255,255,255,0.12)" transform="rotate(30 28 30)" />' +
        // Nudo del globo (triángulo 3D con sombra)
        '<path d="M17,44 L20,47 L23,44 Z" fill="' + palette.knot + '" stroke="' + palette.dark + '" stroke-width="0.3" />' +
        // Base del nudo (pequeño óvalo)
        '<ellipse cx="20" cy="44.5" rx="2.5" ry="1" fill="' + palette.knot + '" opacity="0.8" />' +
      '</svg>' +
    '</span>';
  }

  /**
   * Genera el HTML de un moño (cinta de caja de regalo) — para compatibilidad
   */
  function createBow(colorClass, sizeClass, breathe) {
    colorClass = colorClass || 'magenta';
    sizeClass = sizeClass || 'md';
    var classes = ['dca-bow', 'dca-bow--' + colorClass, 'dca-bow--' + sizeClass];
    if (breathe) classes.push('dca-bow--breathe');

    return '<span class="' + classes.join(' ') + '" aria-hidden="true">' +
      '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">' +
        '<path class="dca-bow__loop-left" d="M50,45 C30,20 5,25 8,45 C11,65 35,60 50,50 Z" />' +
        '<path class="dca-bow__loop-right" d="M50,45 C70,20 95,25 92,45 C89,65 65,60 50,50 Z" />' +
        '<path class="dca-bow__knot" d="M50,40 L58,42 L60,50 L58,58 L50,60 L42,58 L40,50 L42,42 Z" />' +
        '<path class="dca-bow__tail-left" d="M45,55 L35,90 L42,88 L48,60 Z" />' +
        '<path class="dca-bow__tail-right" d="M55,55 L65,90 L58,88 L52,60 Z" />' +
        '<ellipse cx="22" cy="38" rx="6" ry="3" fill="rgba(255,255,255,0.4)" transform="rotate(-25 22 38)" />' +
        '<ellipse cx="78" cy="38" rx="6" ry="3" fill="rgba(255,255,255,0.4)" transform="rotate(25 78 38)" />' +
      '</svg>' +
    '</span>';
  }

  /**
   * Crea efecto confeti al abrir
   */
  function burstConfetti(box) {
    if (!box) return;
    var colors = ['dca-confetti--gold', 'dca-confetti--magenta', 'dca-confetti--rose', 'dca-confetti--cream'];
    var count = 16;
    for (var i = 0; i < count; i++) {
      var c = document.createElement('div');
      c.className = 'dca-confetti ' + colors[i % colors.length];
      var angle = (i / count) * Math.PI * 2;
      var distance = 60 + Math.random() * 40;
      var tx = Math.cos(angle) * distance;
      var ty = Math.sin(angle) * distance - 20;
      c.style.setProperty('--tx', tx + 'px');
      c.style.setProperty('--ty', ty + 'px');
      c.style.setProperty('--tr', (Math.random() * 720 - 360) + 'deg');
      c.style.borderRadius = i % 2 === 0 ? '50%' : '2px';
      box.appendChild(c);
      (function(el) {
        setTimeout(function() { if (el.parentNode) el.parentNode.removeChild(el); }, 1100);
      })(c);
    }
  }

  // Exportar
  window.DCABows = {
    createBow: createBow,
    createBalloon: createBalloon,
    burstConfetti: burstConfetti
  };
})(window);
