/* =========================================================
   DCA · Chatbot "Detallito" — Asistente virtual
   Asistente con identidad DCA que responde preguntas frecuentes
   ========================================================= */

(function(window, document) {
  'use strict';

  // Base de conocimiento del chatbot
  var KNOWLEDGE = [
    {
      keywords: ['hola', 'buenos', 'buenas', 'saludos', 'hey', 'qué tal', 'que tal'],
      response: '¡Hola! Soy Detallito, tu asistente de Detallitos con Amor. Puedo ayudarte con información sobre nuestros regalos, procesos de Talento Humano, formatos y más. ¿En qué te puedo ayudar?',
      suggestions: ['¿Qué productos ofrecen?', '¿Cómo solicito una cotización?', '¿Qué es el aplicativo TH?']
    },
    {
      keywords: ['producto', 'regalo', 'ramo', 'maceta', 'detalle', 'corporativo', 'que hacen', 'qué hacen', 'venden'],
      response: 'En Detallitos con Amor diseñamos regalos personalizados artesanales:\n\n• Ramos Eternos — rosas preservadas que duran años\n• Macetas Curadas — plantas decorativas con macetas personalizadas\n• Detalles Personalizados — cajas, kits y composiciones únicas\n• Colección Corporativa — regalos para eventos y empresas\n\nCada pieza se elabora a mano con materiales seleccionados uno a uno.',
      suggestions: ['¿Cómo solicito una cotización?', '¿Cuánto cuesta?', 'Ver galería']
    },
    {
      keywords: ['cotizar', 'cotización', 'precio', 'costo', 'cuanto', 'cuánto', 'valor', 'pago'],
      response: 'Para solicitar una cotización personalizada:\n\n1. Ve a la sección "Contacto"\n2. Completa el formulario con tu ocasión, presupuesto y fecha\n3. Te respondemos en menos de 24 horas con una propuesta\n\nTambién puedes escribirnos al WhatsApp: +57 305 255 4170',
      suggestions: ['Ir a contacto', '¿Qué productos ofrecen?', '¿Cuál es el horario?']
    },
    {
      keywords: ['contacto', 'telefono', 'teléfono', 'email', 'correo', 'whatsapp', 'donde', 'dónde', 'ubicacion', 'ubicación'],
      response: 'Datos de contacto de Detallitos con Amor:\n\n📧 Email: detallitosconamorth@gmail.com\n📱 WhatsApp: +57 305 255 4170\n🕐 Horario: Lun a sáb, 8:00 a.m. – 6:00 p.m.\n📍 Ubicación: Colombia\n\n¡Escríbenos y te respondemos en menos de 24 horas!',
      suggestions: ['¿Cómo solicito una cotización?', '¿Cuál es el horario?']
    },
    {
      keywords: ['horario', 'atienden', 'abren', 'cierran', 'disponible'],
      response: 'Nuestro horario de atención es:\n\n📅 Lunes a sábado\n🕐 8:00 a.m. – 6:00 p.m.\n\nDomingos cerrado, pero puedes dejarnos un mensaje y te respondemos el lunes.',
      suggestions: ['Datos de contacto', '¿Cómo solicito una cotización?']
    },
    {
      keywords: ['aplicativo', 'talento humano', 'th', 'gestion documental', 'formatos', 'procesos', 'reclutamiento', 'seleccion', 'induccion', 'capacitacion'],
      response: 'El Aplicativo de Gestión Documental TH es nuestra plataforma digital para gestionar todos los procesos de Talento Humano:\n\n• 7 carpetas de procesos: Reclutamiento, Selección, Vinculación, Inducción, Capacitación, Evaluación del desempeño y Bienestar laboral\n• Editor de formatos con caja de calidad APA\n• Exportación a PDF y Word\n• Editor de Excel integrado\n\nLo encuentras en: Entregables → Trimestre 2 → "Abrir aplicativo"',
      suggestions: ['¿Cómo abro el aplicativo?', '¿Qué formatos tiene?', 'Ir a entregables']
    },
    {
      keywords: ['abrir aplicativo', 'como abro', 'cómo abro', 'donde esta', 'dónde está', 'trimestre 2', 'entregable'],
      response: 'Para abrir el aplicativo de Gestión Documental:\n\n1. Ve al menú "Entregables"\n2. Haz clic en la pestaña "Trimestre 2"\n3. Verás una cajita de regalo interactiva\n4. Haz clic en la cajita — se abrirá con confeti 🎉\n5. El aplicativo aparecerá debajo, listo para usar\n\nTambién puedes abrirlo en una pestaña nueva si prefieres.',
      suggestions: ['¿Qué tiene el aplicativo?', 'Ir a entregables']
    },
    {
      keywords: ['pqrsf', 'queja', 'reclamo', 'peticion', 'sugerencia', 'felicitacion', 'problema'],
      response: 'Cumplimos con el sistema PQRSF (Peticiones, Quejas, Reclamos, Sugerencias y Felicitaciones):\n\n• Respuesta garantizada en menos de 24 horas hábiles\n• Canal principal: detallitosconamorth@gmail.com\n• Canal alternativo: WhatsApp +57 305 255 4170\n\nTu voz nos ayuda a mejorar cada día.',
      suggestions: ['Datos de contacto', '¿Cuál es el horario?']
    },
    {
      keywords: ['proceso', 'como trabajan', 'cómo trabajan', 'etapas', 'paso', 'pasos'],
      response: 'Nuestro proceso de elaboración tiene 7 etapas:\n\n1. Consulta — conversamos tu idea y presupuesto\n2. Propuesta — te presentamos opciones y moodboard\n3. Aprobación — cerramos alcance, precio y tiempos\n4. Elaboración — manos artesanas dan vida a tu detalle\n5. Control de calidad — verificamos cada pieza con checklist\n6. Empaque — empaque protector con identidad de marca\n7. Entrega — coordinamos lugar, fecha y confirmación\n\nTrazabilidad total en cada etapa.',
      suggestions: ['¿Cómo solicito una cotización?', '¿Qué productos ofrecen?']
    },
    {
      keywords: ['mision', 'visión', 'vision', 'valores', 'identidad', 'quienes son', 'quiénes son', 'empresa'],
      response: 'Detallitos con Amor · Gifting Studio es una microempresa colombiana dedicada al diseño y elaboración de regalos personalizados artesanales.\n\nEslogan: "Cada detalle cuenta una historia de amor"\n\nValores: Calidad estandarizada, Atención al cliente, PQRSF, Inclusión, Hecho a mano, Trazabilidad total.\n\nConoce más en la sección "Identidad".',
      suggestions: ['Ir a identidad', '¿Qué productos ofrecen?']
    },
    {
      keywords: ['galeria', 'galería', 'fotos', 'ver productos', 'imagenes', 'imágenes'],
      response: 'En nuestra galería encontrarás fotos reales de nuestros productos:\n\n• Ramos Eternos\n• Macetas Curadas\n• Detalles Personalizados\n• Colección Corporativa\n\nVe a la sección "Galería" en el menú superior.',
      suggestions: ['Ir a galería', '¿Cómo solicito una cotización?']
    },
    {
      keywords: ['video', 'inicio', 'portada', 'caja', 'regalo inicio'],
      response: 'En la página de inicio verás una cajita de regalo 3D con un video de presentación de nuestra marca. El video se reproduce una vez y se congela mostrando nuestro logo "Detallitos con Amor".\n\nLa cajita tiene efecto 3D con sombras, brillo glass y bisel dorado.',
      suggestions: ['Ir al inicio', '¿Qué productos ofrecen?']
    },
    {
      keywords: ['gracias', 'genial', 'excelente', 'perfecto', 'ok', 'listo', 'bye', 'chao', 'adios', 'adiós'],
      response: '¡De nada! Me alegra haberte ayudado. Si tienes más preguntas, aquí estaré. ¡Que tengas un día lleno de detalles con amor! 💕',
      suggestions: ['Volver al inicio']
    }
  ];

  // Respuesta por defecto
  var DEFAULT_RESPONSE = {
    response: 'Mmm, no estoy seguro de entender tu pregunta. Pero puedo ayudarte con:\n\n• Información sobre productos y regalos\n• Cotizaciones y precios\n• Datos de contacto\n• El aplicativo de Talento Humano\n• Procesos PQRSF\n• Nuestro proceso de elaboración\n\n¿Sobre cuál de estos temas necesitas ayuda?',
    suggestions: ['¿Qué productos ofrecen?', 'Datos de contacto', '¿Qué es el aplicativo TH?']
  };

  // Buscar la mejor respuesta
  function findResponse(message) {
    var msg = message.toLowerCase().trim();
    var bestMatch = null;
    var bestScore = 0;

    KNOWLEDGE.forEach(function(item) {
      var score = 0;
      item.keywords.forEach(function(keyword) {
        if (msg.indexOf(keyword) >= 0) {
          score += keyword.length;
        }
      });
      if (score > bestScore) {
        bestScore = score;
        bestMatch = item;
      }
    });

    return bestMatch || DEFAULT_RESPONSE;
  }

  // Crear el HTML del chatbot
  function createChatbot() {
    var container = document.createElement('div');
    container.id = 'dca-chatbot';
    container.innerHTML = `
      <style>
        #dca-chatbot {
          position: fixed;
          bottom: 24px;
          right: 24px;
          z-index: 99998;
          font-family: "Poppins", "Segoe UI", system-ui, sans-serif;
        }
        #dca-chatbot-toggle {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: linear-gradient(135deg, #d7068e 0%, #a6056c 100%);
          border: 3px solid #ffd24b;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 14px rgba(215, 6, 142, 0.4), 0 0 0 0 rgba(215, 6, 142, 0.3);
          transition: all 0.3s ease;
          animation: chatbotPulse 2s ease-in-out infinite;
          position: relative;
        }
        @keyframes chatbotPulse {
          0%, 100% { box-shadow: 0 4px 14px rgba(215, 6, 142, 0.4), 0 0 0 0 rgba(215, 6, 142, 0.3); }
          50% { box-shadow: 0 4px 14px rgba(215, 6, 142, 0.4), 0 0 0 12px rgba(215, 6, 142, 0); }
        }
        #dca-chatbot-toggle:hover {
          transform: scale(1.1);
        }
        #dca-chatbot-toggle svg {
          width: 28px;
          height: 28px;
          color: #fff;
        }
        #dca-chatbot-toggle.is-open svg.chat-icon { display: none; }
        #dca-chatbot-toggle:not(.is-open) svg.close-icon { display: none; }
        #dca-chatbot-toggle .badge {
          position: absolute;
          top: -4px;
          right: -4px;
          width: 18px;
          height: 18px;
          background: #ffd24b;
          color: #3f2620;
          border-radius: 50%;
          font-size: 10px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #fffbf7;
        }
        #dca-chatbot-toggle.is-open .badge { display: none; }

        #dca-chatbot-window {
          position: absolute;
          bottom: 76px;
          right: 0;
          width: 360px;
          max-width: calc(100vw - 48px);
          height: 480px;
          max-height: calc(100vh - 120px);
          background: #fffbf7;
          border-radius: 20px;
          box-shadow: 0 20px 60px rgba(0,0,0,0.3), 0 0 0 1px rgba(215,6,142,0.1);
          display: none;
          flex-direction: column;
          overflow: hidden;
          border: 2px solid #ffd24b;
          animation: chatbotSlideIn 0.3s ease;
        }
        @keyframes chatbotSlideIn {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        #dca-chatbot-window.is-open { display: flex; }

        #dca-chatbot-header {
          background: linear-gradient(135deg, #d7068e 0%, #a6056c 100%);
          color: #fff;
          padding: 16px 20px;
          display: flex;
          align-items: center;
          gap: 12px;
          flex-shrink: 0;
        }
        #dca-chatbot-header .avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: #fffbf7;
          border: 2px solid #ffd24b;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          flex-shrink: 0;
        }
        #dca-chatbot-header .avatar img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 50%;
        }
        #dca-chatbot-header .info { flex: 1; }
        #dca-chatbot-header .name {
          font-size: 0.95rem;
          font-weight: 700;
          line-height: 1.2;
        }
        #dca-chatbot-header .status {
          font-size: 0.72rem;
          opacity: 0.9;
          display: flex;
          align-items: center;
          gap: 5px;
        }
        #dca-chatbot-header .status::before {
          content: "";
          width: 7px;
          height: 7px;
          background: #4caf50;
          border-radius: 50%;
          display: inline-block;
        }

        #dca-chatbot-messages {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          background: linear-gradient(180deg, #fff9f3 0%, #fffbf7 100%);
          scrollbar-width: thin;
          scrollbar-color: #d7068e40 transparent;
        }
        #dca-chatbot-messages::-webkit-scrollbar { width: 5px; }
        #dca-chatbot-messages::-webkit-scrollbar-thumb { background: #d7068e40; border-radius: 3px; }

        .chat-msg {
          max-width: 80%;
          padding: 10px 14px;
          border-radius: 14px;
          font-size: 0.85rem;
          line-height: 1.5;
          white-space: pre-wrap;
          word-wrap: break-word;
          animation: msgIn 0.3s ease;
        }
        @keyframes msgIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .chat-msg--bot {
          align-self: flex-start;
          background: #fff4ea;
          color: #3f2620;
          border: 1px solid rgba(215,6,142,0.1);
          border-bottom-left-radius: 4px;
        }
        .chat-msg--user {
          align-self: flex-end;
          background: linear-gradient(135deg, #d7068e 0%, #a6056c 100%);
          color: #fff;
          border-bottom-right-radius: 4px;
        }
        .chat-msg--typing {
          display: flex;
          gap: 4px;
          padding: 14px;
        }
        .chat-msg--typing span {
          width: 7px;
          height: 7px;
          background: #d7068e;
          border-radius: 50%;
          animation: typing 1.4s ease-in-out infinite;
        }
        .chat-msg--typing span:nth-child(2) { animation-delay: 0.2s; }
        .chat-msg--typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
          30% { transform: translateY(-6px); opacity: 1; }
        }

        .chat-suggestions {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
          margin-top: 4px;
        }
        .chat-suggestion {
          background: #fff4ea;
          color: #d7068e;
          border: 1px solid rgba(215,6,142,0.2);
          padding: 6px 12px;
          border-radius: 999px;
          font-size: 0.76rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          font-family: inherit;
        }
        .chat-suggestion:hover {
          background: #d7068e;
          color: #fff;
          transform: translateY(-1px);
        }

        #dca-chatbot-input-area {
          padding: 12px 16px;
          border-top: 1px solid rgba(215,6,142,0.1);
          background: #fffbf7;
          display: flex;
          gap: 8px;
          flex-shrink: 0;
        }
        #dca-chatbot-input {
          flex: 1;
          padding: 10px 14px;
          border: 1.5px solid rgba(215,6,142,0.15);
          border-radius: 999px;
          font-size: 0.85rem;
          font-family: inherit;
          outline: none;
          background: #fff9f3;
          color: #3f2620;
          transition: border-color 0.2s ease;
        }
        #dca-chatbot-input:focus {
          border-color: #d7068e;
        }
        #dca-chatbot-send {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          background: linear-gradient(135deg, #d7068e 0%, #a6056c 100%);
          border: none;
          color: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: transform 0.2s ease;
        }
        #dca-chatbot-send:hover { transform: scale(1.1); }
        #dca-chatbot-send svg { width: 18px; height: 18px; }

        @media (max-width: 480px) {
          #dca-chatbot { bottom: 16px; right: 16px; }
          #dca-chatbot-toggle { width: 52px; height: 52px; }
          #dca-chatbot-window { width: calc(100vw - 32px); height: 420px; }
        }
      </style>

      <button id="dca-chatbot-toggle" aria-label="Abrir chat de Detallito">
        <span class="badge">1</span>
        <svg class="chat-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.9-.9L3 21l1.9-5.7A8.38 8.38 0 0 1 4 11.5 8.5 8.5 0 0 1 12.5 3 8.38 8.38 0 0 1 21 11.5z"/></svg>
        <svg class="close-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>

      <div id="dca-chatbot-window">
        <div id="dca-chatbot-header">
          <div class="avatar">
            <img src="assets/logo-dca.jpeg" alt="Detallito" onerror="this.style.display='none'; this.parentNode.innerHTML='🎀'" />
          </div>
          <div class="info">
            <div class="name">Detallito</div>
            <div class="status">En línea · Asistente DCA</div>
          </div>
        </div>
        <div id="dca-chatbot-messages"></div>
        <div id="dca-chatbot-input-area">
          <input type="text" id="dca-chatbot-input" placeholder="Escribe tu pregunta..." aria-label="Mensaje" />
          <button id="dca-chatbot-send" aria-label="Enviar mensaje">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(container);

    var toggle = container.querySelector('#dca-chatbot-toggle');
    var window_ = container.querySelector('#dca-chatbot-window');
    var messages = container.querySelector('#dca-chatbot-messages');
    var input = container.querySelector('#dca-chatbot-input');
    var sendBtn = container.querySelector('#dca-chatbot-send');
    var isOpen = false;
    var hasWelcomed = false;

    function toggleChat() {
      isOpen = !isOpen;
      toggle.classList.toggle('is-open', isOpen);
      window_.classList.toggle('is-open', isOpen);
      if (isOpen && !hasWelcomed) {
        hasWelcomed = true;
        setTimeout(function() {
          addMessage('bot', '¡Hola! Soy Detallito, tu asistente de Detallitos con Amor. ¿En qué te puedo ayudar hoy?', ['¿Qué productos ofrecen?', '¿Cómo solicito una cotización?', '¿Qué es el aplicativo TH?']);
        }, 300);
        input.focus();
      }
    }

    function addMessage(type, text, suggestions) {
      var msg = document.createElement('div');
      msg.className = 'chat-msg chat-msg--' + type;
      msg.textContent = text;
      messages.appendChild(msg);

      if (suggestions && suggestions.length) {
        var sugDiv = document.createElement('div');
        sugDiv.className = 'chat-suggestions';
        suggestions.forEach(function(s) {
          var btn = document.createElement('button');
          btn.className = 'chat-suggestion';
          btn.textContent = s;
          btn.addEventListener('click', function() {
            input.value = s;
            sendMessage();
          });
          sugDiv.appendChild(btn);
        });
        messages.appendChild(sugDiv);
      }

      messages.scrollTop = messages.scrollHeight;
    }

    function addTyping() {
      var msg = document.createElement('div');
      msg.className = 'chat-msg chat-msg--bot chat-msg--typing';
      msg.id = 'dca-chatbot-typing';
      msg.innerHTML = '<span></span><span></span><span></span>';
      messages.appendChild(msg);
      messages.scrollTop = messages.scrollHeight;
    }

    function removeTyping() {
      var t = document.getElementById('dca-chatbot-typing');
      if (t) t.remove();
    }

    function sendMessage() {
      var text = input.value.trim();
      if (!text) return;

      addMessage('user', text);
      input.value = '';

      addTyping();
      setTimeout(function() {
        removeTyping();
        var result = findResponse(text);
        addMessage('bot', result.response, result.suggestions);
      }, 800 + Math.random() * 600);
    }

    toggle.addEventListener('click', toggleChat);
    sendBtn.addEventListener('click', sendMessage);
    input.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') sendMessage();
    });
  }

  // Inicializar cuando el DOM esté listo
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createChatbot);
  } else {
    createChatbot();
  }
})(window, document);
