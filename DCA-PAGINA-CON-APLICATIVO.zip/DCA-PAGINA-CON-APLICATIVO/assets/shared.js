/* =========================================================
   Detallitos con Amor (DCA) — Scripts compartidos v2
   ========================================================= */

// ----- Navbar móvil (hamburguesa) -----
(function initNavbar() {
  const toggle = document.querySelector('.nav__toggle');
  const links = document.querySelector('.nav__links');
  const cta = document.querySelector('.nav__cta');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    if (cta) cta.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  links.querySelectorAll('a').forEach((a) => {
    a.addEventListener('click', () => {
      links.classList.remove('open');
      if (cta) cta.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
})();

// ----- Navbar sombra al hacer scroll -----
(function initNavShadow() {
  const nav = document.querySelector('.nav');
  if (!nav) return;
  const onScroll = () => {
    if (window.scrollY > 12) {
      nav.style.boxShadow = '0 6px 22px rgba(63, 38, 32, 0.1)';
    } else {
      nav.style.boxShadow = 'none';
    }
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

// ----- Reveal on scroll -----
(function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  if (!('IntersectionObserver' in window)) {
    els.forEach((el) => el.classList.add('is-visible'));
    return;
  }

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  els.forEach((el, i) => {
    el.style.transitionDelay = `${(i % 4) * 80}ms`;
    io.observe(el);
  });
})();

// ----- Año actual en el footer -----
(function setYear() {
  document.querySelectorAll('[data-year]').forEach((el) => {
    el.textContent = String(new Date().getFullYear());
  });
})();

// INTRO VIDEO ya se maneja con script inline en index.html
// para garantizar que se ejecute ANTES de que cargue shared.js

// =========================================================
// LIGHTBOX para la galería de imágenes
// =========================================================
(function initLightbox() {
  const triggers = document.querySelectorAll('[data-lightbox]');
  if (!triggers.length) return;

  // Crear el lightbox si no existe
  let lightbox = document.querySelector('.lightbox');
  if (!lightbox) {
    lightbox = document.createElement('div');
    lightbox.className = 'lightbox';
    lightbox.setAttribute('role', 'dialog');
    lightbox.setAttribute('aria-modal', 'true');
    lightbox.setAttribute('aria-label', 'Imagen ampliada');
    lightbox.innerHTML = `
      <div class="lightbox__inner">
        <button class="lightbox__close" aria-label="Cerrar" type="button">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
        <button class="lightbox__nav lightbox__prev" aria-label="Anterior" type="button">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <img class="lightbox__img" src="" alt="" />
        <div class="lightbox__caption"></div>
        <button class="lightbox__nav lightbox__next" aria-label="Siguiente" type="button">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
      </div>
    `;
    document.body.appendChild(lightbox);
  }

  const img = lightbox.querySelector('.lightbox__img');
  const caption = lightbox.querySelector('.lightbox__caption');
  const closeBtn = lightbox.querySelector('.lightbox__close');
  const prevBtn = lightbox.querySelector('.lightbox__prev');
  const nextBtn = lightbox.querySelector('.lightbox__next');

  let currentIndex = 0;
  const items = Array.from(triggers).map((t) => ({
    src: t.getAttribute('href') || t.dataset.full || t.querySelector('img')?.src,
    title: t.dataset.title || t.querySelector('.gallery-item__caption')?.textContent?.trim() || '',
    eyebrow: t.dataset.eyebrow || '',
    alt: t.querySelector('img')?.alt || t.dataset.title || 'Imagen de galería',
  }));

  function show(idx) {
    currentIndex = (idx + items.length) % items.length;
    const item = items[currentIndex];
    img.src = item.src;
    img.alt = item.alt;
    caption.innerHTML = (item.eyebrow ? `<small>${item.eyebrow}</small>` : '') + item.title;
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function close() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  triggers.forEach((t, i) => {
    t.addEventListener('click', (e) => {
      e.preventDefault();
      show(i);
    });
  });

  closeBtn.addEventListener('click', close);
  prevBtn.addEventListener('click', () => show(currentIndex - 1));
  nextBtn.addEventListener('click', () => show(currentIndex + 1));
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) close();
  });

  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') show(currentIndex - 1);
    if (e.key === 'ArrowRight') show(currentIndex + 1);
  });
})();
